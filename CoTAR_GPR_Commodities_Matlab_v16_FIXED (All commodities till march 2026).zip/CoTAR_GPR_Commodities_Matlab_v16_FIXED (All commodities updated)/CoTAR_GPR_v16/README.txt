===============================================================================
CoTAR Volatility Analysis: Geopolitical Risk (GPR) → Commodity Futures (v16)
===============================================================================

PAPER CONTEXT
-------------
This package applies the CoTAR (Conditional Threshold Autoregression) model
of Motegi & Hamori (2024) to analyze how the Geopolitical Risk Index (GPR)
of Caldara & Iacoviello (2022) drives regime-switching volatility in 18
commodity futures markets.

STUDY PERIOD:  January 2000 – March 2026  (315 monthly observations)

COMMODITIES (18 total):
  Precious Metals   : Gold, Silver, Platinum
  Agriculture       : Wheat, Sweetcorn, Soybean, Cotton, Cocoa, Coffee
  Industrial Metals : Copper, Zinc, Nickel, Lead
  Energy            : WTI Crude Oil (CL1), Brent Crude (CO1),
                      Natural Gas (NG1), RBOB Gasoline (XB1), Heating Oil (HO1)

GPR TYPES (3):  GPR | GPRTHREAT | GPRACT
  Source: Caldara & Iacoviello (2022), matteoiacoviello.com

===============================================================================
FILE LIST
===============================================================================

MAIN SCRIPTS (run in order):
  1. prepare_data_GPR_Commodities.m    — reads xlsx files → generates .txt data
  2. MASTER_CoTAR_GPR_Commodities.m    — full CoTAR estimation + tables + figures

SUBROUTINES (Motegi & Hamori mmc1, unchanged):
  est_CoTAR_v3.m              — CoTAR profiling estimator
  est_CoTAR_gamma_v2.m        — conditional LS given gamma
  est_CoTAR_detail_v2.m       — detailed estimates (SE, CI, regime stats)
  est_CoTAR_gamma_detail_v2.m — detailed estimates given gamma
  Hansen_test_CoTAR_v2.m      — wild-bootstrap Hansen (1996) threshold test
  test_stat_CoTAR_gamma_v1.m  — Wald & LM statistics given gamma
  est_AR_v1.m                 — AR(p) baseline
  DM1995_asy_test_v3.m        — Diebold-Mariano test
  DM_bootstrap_test.m         — bootstrap DM test

DATA INPUT FILES (all xlsx, provided in this folder):
  data_gpr_export.xlsx          — GPR, GPRTHREAT, GPRACT  (Jan 2000 – Mar 2026)
  PRECIOUS METALS_monthly data.xlsx — Gold, Silver, Platinum  (Jan 2000 – Mar 2026)
  METALS_monthly data.xlsx      — Copper, Zinc, Nickel, Lead
  AGRICULTURE_monthly data.xlsx — Wheat, Sweetcorn, Soybean, Cotton, Cocoa, Coffee
  ENERGY_monthly data.xlsx      — CL1, CO1, NG1, XB1, HO1  (5 energy commodities)

GENERATED INTERMEDIATE FILES (created by prepare_data step):
  data_GPR_monthly.txt          — tab-delimited: serial | GPR | GPRTHREAT | GPRACT
  data_commodity_logRV.txt      — tab-delimited: serial | logRV_1…logRV_18
                                   Col 2–19 order:
                                     Gold, Silver, Platinum,
                                     Wheat, Sweetcorn, Soybean, Cotton, Cocoa, Coffee,
                                     Copper, Zinc, Nickel, Lead,
                                     WTI Crude Oil, Brent Crude, Natural Gas,
                                     RBOB Gasoline, Heating Oil

OUTPUT (written to CoTAR_GPR_Results/ subfolder):
  Table1_SampleStatistics.txt/.csv
  Table1b_CoTAR_Parameters.txt/.csv
  Table2_Hansen_Tests.txt/.csv
  Table3_Complete.txt/.csv
  Table3b_RollingWindow_OOS.txt/.csv
  Full_CoTAR_GPR_Results.mat
  Figure1_LogRV_TimeSeries.png/.eps
  Figure2_CoTAR_Threshold.png/.eps
  Figure3_TAR_Threshold.png/.eps
  Figure4_Hansen_Pvalues.png/.eps
  Figure5_R2_Improvement.png/.eps

===============================================================================
STEP-BY-STEP INSTRUCTIONS TO GENERATE ALL FIGURES AND TABLES
===============================================================================

STEP 1 — Start Matlab (R2022a or newer recommended)

STEP 2 — Change directory to this folder (the one containing the .m scripts)
          >> cd 'C:\your\path\to\matlab_cotar_gpr'
          (or use the Matlab "Browse for Folder" button)

STEP 3 — Verify all input files are present:
          >> ls *.xlsx
          You should see:
            data_gpr_export.xlsx
            PRECIOUS METALS_monthly data.xlsx
            METALS_monthly data.xlsx
            AGRICULTURE_monthly data.xlsx
            ENERGY_monthly data.xlsx

STEP 4 — Run the data preparation script:
          >> prepare_data_GPR_Commodities
          This reads all xlsx files and writes two .txt files:
            data_GPR_monthly.txt        (315 rows)
            data_commodity_logRV.txt    (314 rows x 18 commodities + serial col)

STEP 5 — Run the main analysis script:
          >> MASTER_CoTAR_GPR_Commodities
          This performs:
            - CoTAR estimation for all 18 commodities x 3 GPR types
            - Hansen (1996) wild-bootstrap threshold tests
            - Rolling-window OOS forecast evaluation (DM tests)
            - Saves Tables 1, 1b, 2, 3, 3b as .txt and .csv
            - Saves Figures 1-5 as .png and .eps
            - Saves Full_CoTAR_GPR_Results.mat

          Expected runtime: 30–90 minutes (B=999 bootstrap samples)
          To speed up: change B=999 to B=199 in MASTER script (Section 1)

STEP 6 — Results will appear in the CoTAR_GPR_Results/ subfolder.
          Open .txt files for formatted tables or .csv for Excel import.

===============================================================================
MODEL SETTINGS
===============================================================================

  p       = 2        (AR lag order)
  ds      = [1,2,3,4]       (delay candidates)
  ms      = [6,9,12]        (memory size candidates, months)
  cutoff  = 0.15     (minimum regime share for valid estimation)
  B       = 999      (wild-bootstrap samples, Hansen test)
  Robust SE = yes (heteroscedasticity-robust covariance)

CoTAR Model:
  y(t) = alpha1 + phi1(1)*y(t-1) + phi1(2)*y(t-2) + u(t)  if x(t-d) <  mu(t-d-1;m,c)
       = alpha2 + phi2(1)*y(t-1) + phi2(2)*y(t-2) + u(t)  if x(t-d) >= mu(t-d-1;m,c)

  mu(t;m,c) = (m*c)-th order statistic of {x(t), x(t-1), ..., x(t-m+1)}
             = adaptive rolling percentile of log(GPR)
  gamma = [d, m, c] estimated by profile least squares

Hypothesis test:
  H0: beta1 = beta2 (no threshold effect)
  Statistics: sup/ave/exp-Wald and sup/ave/exp-LM
  P-values: wild-bootstrap (Hansen 1996)

===============================================================================
TROUBLESHOOTING
===============================================================================

  Error: "Cannot open file PRECIOUS METALS_monthly data.xlsx"
  → Make sure filenames include spaces exactly as shown. Alternatively,
    rename files to remove spaces and update the filenames in
    prepare_data_GPR_Commodities.m (lines where readtable is called).

  Error about sheet name ('LAST' or 'Sheet1' not found)
  → Open the xlsx file and verify the sheet tab name. Update the
    'Sheet' argument in prepare_data_GPR_Commodities.m accordingly.

  Bootstrap takes too long
  → In MASTER_CoTAR_GPR_Commodities.m, Section 1, change B=999 to B=199.

  Figure save fails (EPS)
  → EPS output requires ghostscript. If not installed, comment out the
    '-depsc' print call in the save_fig() helper at the bottom of MASTER.

===============================================================================
REFERENCES
===============================================================================

Caldara, D., & Iacoviello, M. (2022). Measuring geopolitical risk.
  American Economic Review, 112(4), 1194-1225.

Hansen, B.E. (1996). Inference when a nuisance parameter is not identified
  under the null hypothesis. Econometrica, 64, 413-430.

Harvey, D., Leybourne, S., & Newbold, P. (1997). Testing the equality of
  prediction mean squared errors. International Journal of Forecasting,
  13, 281-291.

Motegi, K., & Hamori, S. (2024). Conditional threshold effects of stock
  market volatility on crude oil market volatility. SSRN #4512310.

Ozdemir, L., Vurur, N.S., Ozen, E., Swiecka, B., & Grima, S. (2025).
  Volatility modeling of the impact of geopolitical risk on commodity markets.
  Economies, 13(4), 88.

===============================================================================
