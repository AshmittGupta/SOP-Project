%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MASTER_CoTAR_GPR_Commodities.m  (v16 — final)
%
% CoTAR Volatility Analysis: Impact of Geopolitical Risk (GPR) on
%    Commodity Futures Markets — 2000M01 to 2026M03
%
% Model: Conditional Threshold Autoregressive (CoTAR)
%   y(t) = alpha1 + SUM phi1(k)*y(t-k) + u(t)   if x(t-d) < mu(t-d-1; m,c)
%         = alpha2 + SUM phi2(k)*y(t-k) + u(t)   if x(t-d) >= mu(t-d-1; m,c)
%   mu(t; m,c) = (m*c)-th order statistic of {x(t), ..., x(t-m+1)}
%
%   y(t) = log-RV of commodity futures  |  x(t) = log(GPR) variant
%
% 18 Commodities:
%   Precious Metals   : Gold, Silver, Platinum
%   Agriculture       : Wheat, Sweetcorn, Soybean, Cotton, Cocoa, Coffee
%   Industrial Metals : Copper, Zinc, Nickel, Lead
%   Energy            : WTI Crude Oil (CL1), Brent Crude (CO1),
%                       Natural Gas (NG1), RBOB Gasoline (XB1),
%                       Heating Oil (HO1)
%
% 3 GPR Types: GPR | GPRTHREAT | GPRACT
%   Source: Caldara & Iacoviello (2022), matteoiacoviello.com
%
% Sample : Jan 2000 – Mar 2026  (315 monthly observations)
%
% PREREQUISITE: Run prepare_data_GPR_Commodities.m first to generate
%   data_GPR_monthly.txt and data_commodity_logRV.txt
%
% REQUIRED SUBROUTINES (Motegi & Hamori mmc1, included unchanged):
%   est_CoTAR_v3.m, est_CoTAR_gamma_v2.m, est_CoTAR_detail_v2.m
%   est_CoTAR_gamma_detail_v2.m, Hansen_test_CoTAR_v2.m
%   test_stat_CoTAR_gamma_v1.m, est_AR_v1.m
%   DM1995_asy_test_v3.m, DM_bootstrap_test.m
%
% OUTPUT: All tables (.txt and .csv) and figures saved in CoTAR_GPR_Results/
%
% References:
%   Motegi & Hamori (2024) SSRN #4512310
%   Caldara & Iacoviello (2022) AER 112(4), 1194-1225
%   Hansen (1996) Econometrica 64, 413-430
%   Ozdemir et al. (2025) Economies 13(4), 88
%   Harvey, Leybourne & Newbold (1997) IJF 13, 281-291
%
% v16: adapted to actual xlsx file formats provided; 18 commodities;
%      sample 2000M01-2026M03
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all; clc;
rng(42);   % reproducibility

%% =========================================================================
%  SECTION 1: SETTINGS
%  =========================================================================

date_start = '2000-01-01';
date_end   = '2026-03-31';

% CoTAR settings (identical to published methodology)
p           = 2;              % AR lag length
ds          = [1, 2, 3, 4];   % delay candidates
ms          = [6, 9, 12];     % memory size candidates (months)
ms_list_tar = [1];            % TAR baseline: single fixed threshold
cutoff      = 0.15;           % minimum regime share
B           = 999;            % bootstrap samples (reduce to 499/199 to speed up)
nomsize     = 0.05;           % nominal size for t-tests
hetero_flag = 1;              % 1 = heteroscedasticity-robust SE

% ── Commodity display names (used in ALL tables and figures) ──────────────
commodity_names = {'Gold','Silver','Platinum', ...
                   'Wheat','Sweetcorn','Soybean','Cotton','Cocoa','Coffee', ...
                   'Copper','Zinc','Nickel','Lead', ...
                   'WTI Crude Oil','Brent Crude','Natural Gas', ...
                   'RBOB Gasoline','Heating Oil'};
num_commodities = numel(commodity_names);   % 18

commodity_groups = {'Precious Metals','Precious Metals','Precious Metals', ...
                    'Agriculture','Agriculture','Agriculture','Agriculture','Agriculture','Agriculture', ...
                    'Industrial Metals','Industrial Metals','Industrial Metals','Industrial Metals', ...
                    'Energy','Energy','Energy','Energy','Energy'};

% Internal column keys for price tables (must match actual variable names)
% Precious Metals: col2=Gold, col3=Silver, col4=Platinum
% Metals: col2=Copper, col3=Zinc, col4=Nickel, col5=Lead
% Agriculture: col2=Wheat, col3=Sweetcorn, col4=Soybean, col5=Cotton, col6=Cocoa, col7=Coffee
% Energy (Sheet1): col2=WTI_Crude_Oil, col3=Brent_Crude, col4=Natural_Gas, col5=RBOB_Gasoline, col6=Heating_Oil

% GPR variable labels
gpr_names = {'GPR', 'GPRTHREAT', 'GPRACT'};
num_gpr   = numel(gpr_names);

% Output directory
output_dir = [fullfile(pwd, 'CoTAR_GPR_Results') filesep];
if ~exist(output_dir, 'dir')
    [ok, msg] = mkdir(output_dir);
    if ~ok, error('Cannot create output dir: %s', msg); end
end

%% =========================================================================
%  SECTION 2: LOAD DATA
%  =========================================================================
fprintf('Loading data...\n');

% --- GPR data ---
load data_GPR_monthly.txt
% Format: [excel_serial, GPR, GPRTHREAT, GPRACT]
dates_gpr_matlab = datetime(data_GPR_monthly(:,1), 'ConvertFrom', 'excel');
GPR_raw       = data_GPR_monthly(:,2);
GPRTHREAT_raw = data_GPR_monthly(:,3);
GPRACT_raw    = data_GPR_monthly(:,4);

% --- Commodity log-RV data ---
load data_commodity_logRV.txt
% Format: [excel_serial, logRV_1, ..., logRV_18]
dates_comm_matlab = datetime(data_commodity_logRV(:,1), 'ConvertFrom', 'excel');
logRV_all = data_commodity_logRV(:, 2:end);   % N x 18

% --- Filter to study window ---
start_dt = datetime(date_start);
end_dt   = datetime(date_end);

gpr_mask  = (dates_gpr_matlab  >= start_dt) & (dates_gpr_matlab  <= end_dt);
comm_mask = (dates_comm_matlab >= start_dt) & (dates_comm_matlab <= end_dt);

dates_gpr = dates_gpr_matlab(gpr_mask);
GPR       = log(max(GPR_raw(gpr_mask),       0.01));   % log-GPR
GPRTHREAT = log(max(GPRTHREAT_raw(gpr_mask), 0.01));   % log-GPRTHREAT
GPRACT    = log(max(GPRACT_raw(gpr_mask),    0.01));   % log-GPRACT
GPR_matrix = [GPR, GPRTHREAT, GPRACT];   % N x 3

dates_comm = dates_comm_matlab(comm_mask);
logRV_data = logRV_all(comm_mask, :);   % N x 18

% --- ALIGN USING MONTH-YEAR (ROBUST) ---

gpr_ym  = year(dates_gpr)*100 + month(dates_gpr);
comm_ym = year(dates_comm)*100 + month(dates_comm);

all_ym = unique([gpr_ym; comm_ym]);

GPR_aligned   = NaN(length(all_ym), num_gpr);
logRV_aligned = NaN(length(all_ym), num_commodities);
dates_aligned = NaT(length(all_ym),1);

for i = 1:length(all_ym)
    
    % find matching month-year
    idx_g = find(gpr_ym == all_ym(i), 1);
    idx_c = find(comm_ym == all_ym(i), 1);

    if ~isempty(idx_g)
        GPR_aligned(i,:) = GPR_matrix(idx_g,:);
        dates_aligned(i) = dates_gpr(idx_g);
    elseif ~isempty(idx_c)
        dates_aligned(i) = dates_comm(idx_c);
    end

    if ~isempty(idx_c)
        logRV_aligned(i,:) = logRV_data(idx_c,:);
    end
end
% --- REMOVE BAD ROWS ---
valid_rows = ~isnan(GPR_aligned(:,1)) & ~all(isnan(logRV_aligned),2);

GPR_aligned   = GPR_aligned(valid_rows,:);
logRV_aligned = logRV_aligned(valid_rows,:);
dates_aligned = dates_aligned(valid_rows);

n = length(dates_aligned);

%% =========================================================================
%  SECTION 3: PRE-ALLOCATE RESULT ARRAYS
%  =========================================================================
results_d      = zeros(num_commodities, num_gpr);
results_m      = zeros(num_commodities, num_gpr);
results_c      = zeros(num_commodities, num_gpr);
results_alpha1 = zeros(num_commodities, num_gpr);
results_alpha2 = zeros(num_commodities, num_gpr);
results_phi1   = zeros(num_commodities, num_gpr, p);
results_phi2   = zeros(num_commodities, num_gpr, p);
results_se1    = zeros(num_commodities, num_gpr, p+1);
results_se2    = zeros(num_commodities, num_gpr, p+1);
results_tstat1 = zeros(num_commodities, num_gpr, p+1);
results_tstat2 = zeros(num_commodities, num_gpr, p+1);
results_pval1  = zeros(num_commodities, num_gpr, p+1);
results_pval2  = zeros(num_commodities, num_gpr, p+1);
results_share1  = zeros(num_commodities, num_gpr);
results_share2  = zeros(num_commodities, num_gpr);
results_dur1    = zeros(num_commodities, num_gpr);
results_dur2    = zeros(num_commodities, num_gpr);
results_trans11 = zeros(num_commodities, num_gpr);
results_trans22 = zeros(num_commodities, num_gpr);
results_SSR_CoTAR = zeros(num_commodities, num_gpr);
results_SSR_AR    = zeros(num_commodities, num_gpr);
results_R2_improv = zeros(num_commodities, num_gpr);
results_yhat_oos  = zeros(num_commodities, num_gpr);
results_pvals     = zeros(num_commodities, num_gpr, 6);
results_waldstats = zeros(num_commodities, num_gpr, 3);
results_LMstats   = zeros(num_commodities, num_gpr, 3);

%% =========================================================================
%  SECTION 4: MAIN LOOP — CoTAR ESTIMATION
%  =========================================================================
K = 2*(p+1);
R = [eye(p+1), -eye(p+1)];    % H0: beta1 = beta2
q = zeros(p+1, 1);

for g = 1:num_gpr
    fprintf('\n=== GPR type: %s ===\n', gpr_names{g});
    x = GPR_aligned(:, g);

    for c_idx = 1:num_commodities
        y = logRV_aligned(:, c_idx);
        valid = ~isnan(y) & ~isnan(x);
        y_use = y(valid);
        x_use = x(valid);
        n_use = sum(valid);

        fprintf('  %-22s  n=%d  ', commodity_names{c_idx}, n_use);

        if n_use < 40
            fprintf('[SKIP: too few obs]\n'); continue;
        end

        % (A) CoTAR detailed estimation
        res = est_CoTAR_detail_v2(y_use, x_use, p, ds, ms, cutoff, hetero_flag, nomsize);
        if isempty(res)
            fprintf('[SKIP: all gammas failed cutoff]\n'); continue;
        end

        d_hat  = res.gamma(1);  m_hat = res.gamma(2);  c_hat = res.gamma(3);
        beta   = res.beta_hat;
        alpha1 = beta(1);       phi1  = beta(2:p+1);
        alpha2 = beta(p+2);     phi2  = beta(p+3:K);

        % (B) AR baseline SSR
        [beta_AR, ~] = est_AR_v1(y_use, p);
        nobs_AR = n_use - p;
        Y_AR    = y_use(p+1:end);
        Z_AR    = ones(nobs_AR, p+1);
        for k = 1:p
            Z_AR(:, k+1) = y_use(p+1-k:n_use-k);
        end
        SSR_AR = sum((Y_AR - Z_AR*beta_AR).^2);

        % (C) CoTAR SSR and R2
        [~, SSR_CoTAR] = est_CoTAR_gamma_v2(y_use, x_use, p, res.gamma, cutoff);
        R2_improv = 1 - SSR_CoTAR/SSR_AR;

        % (D) Hansen bootstrap test
        pvals = Hansen_test_CoTAR_v2(y_use, x_use, p, ds, ms, B, cutoff, ...
                                      hetero_flag, R, q);

        % (E) Raw Wald / LM statistics
        wald_raw = [];  lm_raw = [];
        for gi = 1:numel(ds)
            for mi = 1:numel(ms)
                m_loop = ms(mi);
                for j = 1:m_loop
                    gamma_loop = [ds(gi); m_loop; j/m_loop];
                    ts = test_stat_CoTAR_gamma_v1(y_use, x_use, p, gamma_loop, ...
                                                   cutoff, hetero_flag, R, q);
                    if ts.share_flag == 1
                        wald_raw(end+1) = ts.wald_stat;   %#ok<AGROW>
                        lm_raw(end+1)   = ts.LM_stat;     %#ok<AGROW>
                    end
                end
            end
        end
        if isempty(wald_raw)
            sup_w=NaN; ave_w=NaN; exp_w=NaN;
            sup_lm=NaN; ave_lm=NaN; exp_lm=NaN;
        else
            sup_w  = max(wald_raw);    ave_w  = mean(wald_raw);
            exp_w  = log(mean(exp(0.5*wald_raw)));
            sup_lm = max(lm_raw);      ave_lm = mean(lm_raw);
            exp_lm = log(mean(exp(0.5*lm_raw)));
        end

        % Store results
        results_d(c_idx,g)=d_hat;  results_m(c_idx,g)=m_hat;  results_c(c_idx,g)=c_hat;
        results_alpha1(c_idx,g)=alpha1;  results_alpha2(c_idx,g)=alpha2;
        results_phi1(c_idx,g,:)=phi1;    results_phi2(c_idx,g,:)=phi2;
        results_se1(c_idx,g,:)=res.se(1:p+1);
        results_se2(c_idx,g,:)=res.se(p+2:K);
        results_tstat1(c_idx,g,:)=res.tstat(1:p+1);
        results_tstat2(c_idx,g,:)=res.tstat(p+2:K);
        results_pval1(c_idx,g,:)=res.pval(1:p+1);
        results_pval2(c_idx,g,:)=res.pval(p+2:K);
        results_share1(c_idx,g)=res.share1;  results_share2(c_idx,g)=res.share2;
        results_dur1(c_idx,g)=res.ave_duration1;
        results_dur2(c_idx,g)=res.ave_duration2;
        results_trans11(c_idx,g)=res.share11;
        results_trans22(c_idx,g)=res.share22;
        results_SSR_AR(c_idx,g)=SSR_AR;
        results_SSR_CoTAR(c_idx,g)=SSR_CoTAR;
        results_R2_improv(c_idx,g)=R2_improv;
        results_yhat_oos(c_idx,g)=res.y_hat_outsample;
        results_pvals(c_idx,g,:)=[pvals(:)'];
        results_waldstats(c_idx,g,:)=[sup_w,ave_w,exp_w];
        results_LMstats(c_idx,g,:)=[sup_lm,ave_lm,exp_lm];

        sig='';
        if     pvals(1)<0.01, sig='***';
        elseif pvals(1)<0.05, sig='**';
        elseif pvals(1)<0.10, sig='*'; end
        fprintf('d=%d m=%d c=%.2f | dR2=%.3f | p(supW)=%.3f %s\n', ...
                d_hat,m_hat,c_hat,R2_improv,pvals(1),sig);
    end
end

%% =========================================================================
%  SECTION 5: RELOAD RAW PRICES FOR TABLE 1 / FIGURES
%  =========================================================================
fprintf('\nReloading raw prices for statistics and figures...\n');

try
    pm_raw = load_price_table('PRECIOUS METALS_monthly data.xlsx', 'LAST', ...
                              {'Date','Gold','Silver','Platinum'}, date_start, date_end);
    ag_raw = load_price_table('AGRICULTURE_monthly data.xlsx', 'LAST', ...
                              {'Date','Wheat','Sweetcorn','Soybean','Cotton','Cocoa','Coffee'}, ...
                              date_start, date_end);
    me_raw = load_price_table('METALS_monthly data.xlsx', 'LAST', ...
                              {'Date','Copper','Zinc','Nickel','Lead'}, date_start, date_end);
    % --- ENERGY RAW (FIXED) ---
brent = readtable('Brent_Crude_clean.csv');
wti   = readtable('WTI_Crude_Oil_clean.csv');
ng    = readtable('Natural_Gas_clean.csv');
rbob  = readtable('RBOB_Gasoline_clean.csv');
ho    = readtable('Heating_Oil_clean.csv');

% Convert to datetime
brent.Date = datetime(brent.Date);
wti.Date   = datetime(wti.Date);
ng.Date    = datetime(ng.Date);
rbob.Date  = datetime(rbob.Date);
ho.Date    = datetime(ho.Date);

% Convert to timetable
brent = table2timetable(brent);
wti   = table2timetable(wti);
ng    = table2timetable(ng);
rbob  = table2timetable(rbob);
ho    = table2timetable(ho);

% Synchronize all (KEY FIX)
en_tt = synchronize(brent, wti, ng, rbob, ho);

% Convert back to table
en_raw = timetable2table(en_tt);

% Rename properly
en_raw.Properties.VariableNames = ...
    {'Date','Brent_Crude','WTI_Crude_Oil','Natural_Gas','RBOB_Gasoline','Heating_Oil'};
        prices_loaded = true;
catch ME_p
    prices_loaded = false;
    warning('Price reload failed: %s', ME_p.message);
end

%% =========================================================================
%  SECTION 6: TABLE 1 — SAMPLE STATISTICS
%  =========================================================================
fprintf('Saving Table 1...\n');

fid  = fopen([output_dir 'Table1_SampleStatistics.txt'], 'w');
fid2 = fopen([output_dir 'Table1_SampleStatistics.csv'], 'w');
fprintf(fid,  'Table 1. Sample Statistics of Monthly Log-Realized Variances\n');
fprintf(fid,  'Sample: %s to %s  (%d monthly obs)\n\n', date_start, date_end, n);
fprintf(fid,  '%-22s  %-5s  %5s  %8s  %8s  %8s  %8s  %8s  %8s  %8s\n', ...
        'Series','RV','N','Mean','Median','Min','Max','StDev','Skew','Kurt');
fprintf(fid,  '%s\n', repmat('-',1,110));
fprintf(fid2, 'Group,Series,RV_type,N,Mean,Median,Min,Max,StDev,Skew,Kurt\n');

% Price-to-column mapping: {commodity_name, price_table, internal_col_key}
if prices_loaded
    price_map = { ...
        'Gold',          pm_raw, 'Gold'; ...
        'Silver',        pm_raw, 'Silver'; ...
        'Platinum',      pm_raw, 'Platinum'; ...
        'Wheat',         ag_raw, 'Wheat'; ...
        'Sweetcorn',     ag_raw, 'Sweetcorn'; ...
        'Soybean',       ag_raw, 'Soybean'; ...
        'Cotton',        ag_raw, 'Cotton'; ...
        'Cocoa',         ag_raw, 'Cocoa'; ...
        'Coffee',        ag_raw, 'Coffee'; ...
        'Copper',        me_raw, 'Copper'; ...
        'Zinc',          me_raw, 'Zinc'; ...
        'Nickel',        me_raw, 'Nickel'; ...
        'Lead',          me_raw, 'Lead'; ...
        'WTI Crude Oil', en_raw, 'WTI_Crude_Oil'; ...
        'Brent Crude',   en_raw, 'Brent_Crude'; ...
        'Natural Gas',   en_raw, 'Natural_Gas'; ...
        'RBOB Gasoline', en_raw, 'RBOB_Gasoline'; ...
        'Heating Oil',   en_raw, 'Heating_Oil'; ...
    };

    rv_type_labels     = {'RV_pm','RV_pos','RV_neg'};
    rv_type_labels_txt = {'RV\pm','RV+','RV-'};

    for c_idx = 1:num_commodities
        name    = price_map{c_idx,1};
        tbl     = price_map{c_idx,2};
        col_key = price_map{c_idx,3};
        grp     = commodity_groups{c_idx};

        prices = tbl.(col_key);
        prices(prices <= 0) = NaN;
        log_ret = diff(log(prices));
        r2 = log_ret .^ 2;
        r2(r2 == 0) = NaN;
        rv_tot  = log(r2);
        rv_good = rv_tot;  rv_good(log_ret <= 0) = NaN;
        rv_bad  = rv_tot;  rv_bad(log_ret  >= 0) = NaN;
        rv_sets = {rv_tot, rv_good, rv_bad};

        for rv_i = 1:3
            v = rv_sets{rv_i};  v = v(~isnan(v));  N_v = numel(v);
            if N_v < 5, continue; end
            fprintf(fid,  '%-22s  %-5s  %5d  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f\n', ...
                    name, rv_type_labels_txt{rv_i}, N_v, mean(v), median(v), ...
                    min(v), max(v), std(v,0), skewness(v), kurtosis(v));
            fprintf(fid2, '%s,%s,%s,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n', ...
                    grp, name, rv_type_labels{rv_i}, N_v, mean(v), median(v), ...
                    min(v), max(v), std(v,0), skewness(v), kurtosis(v));
        end
        fprintf(fid, '\n');
    end
end

% GPR statistics
fprintf(fid, '\n%s\n', repmat('-',1,110));
fprintf(fid, 'Threshold Variables: log(GPR) variants\n%s\n', repmat('-',1,110));
for g = 1:num_gpr
    v = GPR_aligned(:,g);  v = v(~isnan(v));  N_g = numel(v);
    fprintf(fid,  '%-22s  %-5s  %5d  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f\n', ...
            gpr_names{g},'log',N_g,mean(v),median(v),min(v),max(v),std(v,0),skewness(v),kurtosis(v));
    fprintf(fid2, 'GPR,%s,log,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n', ...
            gpr_names{g},N_g,mean(v),median(v),min(v),max(v),std(v,0),skewness(v),kurtosis(v));
end

fprintf(fid,'\n%s\nNOTES:\n', repmat('-',1,110));
fprintf(fid,'  RV\\pm = log(r_t^2): total log-realized variance\n');
fprintf(fid,'  RV+   = log(r_t^2) on months with positive return\n');
fprintf(fid,'  RV-   = log(r_t^2) on months with negative return\n');
fprintf(fid,'  r_t   = log(P_t/P_{t-1}): monthly log-return\n');
fprintf(fid,'  kurt  = kurtosis (normal = 3)\n');
fprintf(fid,'  Energy: WTI Crude Oil(CL1), Brent Crude(CO1), Natural Gas(NG1),\n');
fprintf(fid,'          RBOB Gasoline(XB1), Heating Oil(HO1)\n');
fclose(fid);  fclose(fid2);
fprintf('  -> Table1_SampleStatistics.txt / .csv\n');

%% =========================================================================
%  SECTION 7: TABLE 1b — CoTAR PARAMETER ESTIMATES
%  =========================================================================
fprintf('Saving Table 1b...\n');

fid  = fopen([output_dir 'Table1b_CoTAR_Parameters.txt'], 'w');
fid2 = fopen([output_dir 'Table1b_CoTAR_Parameters.csv'], 'w');
fprintf(fid,  'Table 1b. CoTAR Parameter Estimates\n');
fprintf(fid,  'Sample: %s to %s  | p=%d | cutoff=%.2f | Robust SE\n\n', ...
        date_start, date_end, p, cutoff);
fprintf(fid2, ['Group,Commodity,GPR_Type,N,d,m,c,' ...
               'alpha1,SE_a1,t_a1,p_a1,phi1_1,SE_p11,t_p11,p_p11,phi1_2,SE_p12,t_p12,p_p12,' ...
               'alpha2,SE_a2,t_a2,p_a2,phi2_1,SE_p21,t_p21,p_p21,phi2_2,SE_p22,t_p22,p_p22,' ...
               'Shr_R1,Shr_R2,Dur_R1,Dur_R2,T11,T22,' ...
               'sig_a1,sig_p11,sig_p12,sig_a2,sig_p21,sig_p22\n']);

W = 230;
for g = 1:num_gpr
    fprintf(fid,'\n%s\nGPR Type: %s\n%s\n',repmat('=',1,W),gpr_names{g},repmat('=',1,W));
    % Header row
    fprintf(fid,'%-22s  %4s %4s %4s %6s  ', 'Commodity','N','d','m','c');
    fprintf(fid,'%8s %7s %7s %5s  ','alpha1','SE','t','p');
    fprintf(fid,'%8s %7s %7s %5s  ','phi1_1','SE','t','p');
    fprintf(fid,'%8s %7s %7s %5s  ','phi1_2','SE','t','p');
    fprintf(fid,'%8s %7s %7s %5s  ','alpha2','SE','t','p');
    fprintf(fid,'%8s %7s %7s %5s  ','phi2_1','SE','t','p');
    fprintf(fid,'%8s %7s %7s %5s  ','phi2_2','SE','t','p');
    fprintf(fid,'%7s %7s %7s %7s %6s %6s  ','Shr_R1','Shr_R2','Dur_R1','Dur_R2','T11','T22');
    fprintf(fid,'%5s %5s %5s %5s %5s %5s\n','sa1','sp11','sp12','sa2','sp21','sp22');
    fprintf(fid,'%s\n',repmat('-',1,W));

    for c_idx = 1:num_commodities
        if results_d(c_idx,g)==0, continue; end
        a1=results_alpha1(c_idx,g); a2=results_alpha2(c_idx,g);
        p11=results_phi1(c_idx,g,1); p12=results_phi1(c_idx,g,2);
        p21=results_phi2(c_idx,g,1); p22=results_phi2(c_idx,g,2);
        se_a1=results_se1(c_idx,g,1); se_p11=results_se1(c_idx,g,2); se_p12=results_se1(c_idx,g,3);
        se_a2=results_se2(c_idx,g,1); se_p21=results_se2(c_idx,g,2); se_p22=results_se2(c_idx,g,3);
        t_a1=results_tstat1(c_idx,g,1); t_p11=results_tstat1(c_idx,g,2); t_p12=results_tstat1(c_idx,g,3);
        t_a2=results_tstat2(c_idx,g,1); t_p21=results_tstat2(c_idx,g,2); t_p22=results_tstat2(c_idx,g,3);
        pv_a1=results_pval1(c_idx,g,1); pv_p11=results_pval1(c_idx,g,2); pv_p12=results_pval1(c_idx,g,3);
        pv_a2=results_pval2(c_idx,g,1); pv_p21=results_pval2(c_idx,g,2); pv_p22=results_pval2(c_idx,g,3);
        sh1=results_share1(c_idx,g); sh2=results_share2(c_idx,g);
        d1=results_dur1(c_idx,g); d2=results_dur2(c_idx,g);
        t11=results_trans11(c_idx,g); t22=results_trans22(c_idx,g);
        dh=results_d(c_idx,g); mh=results_m(c_idx,g); ch=results_c(c_idx,g);

        fprintf(fid,'%-22s  %4d %4d %4d %6.4f  ',commodity_names{c_idx},n,dh,mh,ch);
        fprintf(fid,'%8.4f %7.4f %7.3f %5.3f  ',a1,se_a1,t_a1,pv_a1);
        fprintf(fid,'%8.4f %7.4f %7.3f %5.3f  ',p11,se_p11,t_p11,pv_p11);
        fprintf(fid,'%8.4f %7.4f %7.3f %5.3f  ',p12,se_p12,t_p12,pv_p12);
        fprintf(fid,'%8.4f %7.4f %7.3f %5.3f  ',a2,se_a2,t_a2,pv_a2);
        fprintf(fid,'%8.4f %7.4f %7.3f %5.3f  ',p21,se_p21,t_p21,pv_p21);
        fprintf(fid,'%8.4f %7.4f %7.3f %5.3f  ',p22,se_p22,t_p22,pv_p22);
        fprintf(fid,'%7.4f %7.4f %7.2f %7.2f %6.4f %6.4f  ',sh1,sh2,d1,d2,t11,t22);
        fprintf(fid,'%5s %5s %5s %5s %5s %5s\n', ...
                getsig(pv_a1),getsig(pv_p11),getsig(pv_p12), ...
                getsig(pv_a2),getsig(pv_p21),getsig(pv_p22));

        fprintf(fid2,'%s,%s,%s,%d,%d,%d,%.4f,', ...
                commodity_groups{c_idx},commodity_names{c_idx},gpr_names{g},n,dh,mh,ch);
        fprintf(fid2,'%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,', ...
                a1,se_a1,t_a1,pv_a1,p11,se_p11,t_p11,pv_p11,p12,se_p12,t_p12,pv_p12);
        fprintf(fid2,'%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,', ...
                a2,se_a2,t_a2,pv_a2,p21,se_p21,t_p21,pv_p21,p22,se_p22,t_p22,pv_p22);
        fprintf(fid2,'%.4f,%.4f,%.2f,%.2f,%.4f,%.4f,', sh1,sh2,d1,d2,t11,t22);
        fprintf(fid2,'%s,%s,%s,%s,%s,%s\n', ...
                strtrim(getsig(pv_a1)),strtrim(getsig(pv_p11)),strtrim(getsig(pv_p12)), ...
                strtrim(getsig(pv_a2)),strtrim(getsig(pv_p21)),strtrim(getsig(pv_p22)));
    end
end
fprintf(fid,'\n%s\nNOTES:\n',repmat('-',1,W));
fprintf(fid,'  Regime 1 = low-GPR: x(t-d) < mu(t-d-1;m,c)\n');
fprintf(fid,'  Regime 2 = high-GPR: x(t-d) >= mu(t-d-1;m,c)\n');
fprintf(fid,'  SE = heteroscedasticity-robust SE  | *** p<0.01 ** p<0.05 * p<0.10\n');
fclose(fid);  fclose(fid2);
fprintf('  -> Table1b_CoTAR_Parameters.txt / .csv\n');

%% =========================================================================
%  SECTION 8: TABLE 2 — HANSEN TESTS
%  =========================================================================
fprintf('Saving Table 2...\n');

fid  = fopen([output_dir 'Table2_Hansen_Tests.txt'], 'w');
fid2 = fopen([output_dir 'Table2_Hansen_Tests.csv'], 'w');
fprintf(fid,  'Table 2. Wild-Bootstrap Hansen (1996) Threshold Tests\n');
fprintf(fid,  'H0: beta1 = beta2 (no threshold effect) | B=%d | cutoff=%.2f\n\n',B,cutoff);
fprintf(fid2, 'Group,Commodity,GPR_Type,d,m,c,supW,aveW,expW,supLM,aveLM,expLM,p_supW,p_aveW,p_expW,p_supLM,p_aveLM,p_expLM,sig_supW\n');

W = 180;
for g = 1:num_gpr
    fprintf(fid,'\n%s\nGPR Type: %s\n%s\n',repmat('=',1,W),gpr_names{g},repmat('=',1,W));
    fprintf(fid,'%-22s %4s %4s %6s  %10s %10s %10s  %10s %10s %10s  %10s %10s %10s  %10s %10s %10s\n', ...
            'Commodity','d','m','c','supWald','aveWald','expWald','supLM','aveLM','expLM', ...
            'p(supW)','p(aveW)','p(expW)','p(supLM)','p(aveLM)','p(expLM)');
    fprintf(fid,'%s\n',repmat('-',1,W));

    for c_idx = 1:num_commodities
        if results_d(c_idx,g)==0, continue; end
        dh=results_d(c_idx,g); mh=results_m(c_idx,g); ch=results_c(c_idx,g);
        sw=results_waldstats(c_idx,g,1); aw=results_waldstats(c_idx,g,2); ew=results_waldstats(c_idx,g,3);
        sl=results_LMstats(c_idx,g,1);  al=results_LMstats(c_idx,g,2);   el=results_LMstats(c_idx,g,3);
        pv=squeeze(results_pvals(c_idx,g,:));

        fprintf(fid,'%-22s %4d %4d %6.4f  %10.4f %10.4f %10.4f  %10.4f %10.4f %10.4f  %10.4f %10.4f %10.4f  %10.4f %10.4f %10.4f %s\n', ...
                commodity_names{c_idx},dh,mh,ch,sw,aw,ew,sl,al,el, ...
                pv(1),pv(2),pv(3),pv(4),pv(5),pv(6),strtrim(getsig(pv(1))));
        fprintf(fid2,'%s,%s,%s,%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%s\n', ...
                commodity_groups{c_idx},commodity_names{c_idx},gpr_names{g},dh,mh,ch, ...
                sw,aw,ew,sl,al,el,pv(1),pv(2),pv(3),pv(4),pv(5),pv(6),strtrim(getsig(pv(1))));
    end
end
fprintf(fid,'\n%s\nNOTES: *** p<0.01 ** p<0.05 * p<0.10  |  B=%d bootstrap samples\n',repmat('-',1,W),B);
fclose(fid);  fclose(fid2);
fprintf('  -> Table2_Hansen_Tests.txt / .csv\n');

%% =========================================================================
%  SECTION 9: TABLE 3 — SSR COMPARISON
%  =========================================================================
fprintf('Saving Table 3...\n');

fid  = fopen([output_dir 'Table3_Complete.txt'], 'w');
fid2 = fopen([output_dir 'Table3_Complete.csv'], 'w');
fprintf(fid,  'Table 3. SSR Comparison: CoTAR vs AR\n');
fprintf(fid,  'Sample: %s to %s\n\n', date_start, date_end);
fprintf(fid2, 'Group,Commodity,GPR_Type,d,m,c,SSR_AR,SSR_CoTAR,DeltaR2,p_supWald,sig\n');

for g = 1:num_gpr
    fprintf(fid,'\n%s\nGPR Type: %s\n%s\n',repmat('=',1,110),gpr_names{g},repmat('=',1,110));
    fprintf(fid,'%-22s %4s %4s %6s  %14s  %14s  %10s  %10s\n', ...
            'Commodity','d','m','c','SSR_AR','SSR_CoTAR','DeltaR2','p(supW)');
    fprintf(fid,'%s\n',repmat('-',1,110));
    for c_idx = 1:num_commodities
        if results_d(c_idx,g)==0, continue; end
        dh=results_d(c_idx,g); mh=results_m(c_idx,g); ch=results_c(c_idx,g);
        pv=results_pvals(c_idx,g,1);
        fprintf(fid,'%-22s %4d %4d %6.4f  %14.4f  %14.4f  %10.4f  %10.4f %s\n', ...
                commodity_names{c_idx},dh,mh,ch, ...
                results_SSR_AR(c_idx,g),results_SSR_CoTAR(c_idx,g), ...
                results_R2_improv(c_idx,g),pv,strtrim(getsig(pv)));
        fprintf(fid2,'%s,%s,%s,%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%s\n', ...
                commodity_groups{c_idx},commodity_names{c_idx},gpr_names{g},dh,mh,ch, ...
                results_SSR_AR(c_idx,g),results_SSR_CoTAR(c_idx,g), ...
                results_R2_improv(c_idx,g),pv,strtrim(getsig(pv)));
    end
end
fclose(fid);  fclose(fid2);
fprintf('  -> Table3_Complete.txt / .csv\n');

%% =========================================================================
%  SECTION 10: TABLE 3b — ROLLING WINDOW OOS FORECAST
%  =========================================================================
fprintf('Saving Table 3b (rolling OOS)...\n');

fid  = fopen([output_dir 'Table3b_RollingWindow_OOS.txt'], 'w');
fid2 = fopen([output_dir 'Table3b_RollingWindow_OOS.csv'], 'w');
fprintf(fid,'Table 3b. Rolling Window Out-of-Sample Forecast Comparison\n');
fprintf(fid,'Training: 80%%  |  Loss diff: d(t)=MSE_TAR-MSE_CoTAR\n\n');
fprintf(fid,'%-22s  %-10s  %4s %5s  %12s %12s %12s %12s  %14s %14s %14s\n', ...
        'Commodity','GPR_Type','N','T', ...
        'RMSE_const','RMSE_AR','RMSE_TAR','RMSE_CoTAR', ...
        'p(H0^eq)','p(H1^TAR)','p(H1^CoTAR)');
fprintf(fid,'%s\n',repmat('-',1,155));
fprintf(fid2,'Group,Commodity,GPR_Type,N,T,win_size,RMSE_const,RMSE_AR,RMSE_TAR,RMSE_CoTAR,p_H0eq,p_H1tar,p_H1cotar,sig_H0eq,sig_H1tar,sig_H1cotar\n');

for g = 1:num_gpr
    fprintf(fid,'\n[GPR Type: %s]\n%s\n',gpr_names{g},repmat('-',1,140));
    for c_idx = 1:num_commodities
        if results_d(c_idx,g)==0, continue; end
        y_tmp=logRV_aligned(:,c_idx);  x_tmp=GPR_aligned(:,g);
        valid=~isnan(y_tmp)&~isnan(x_tmp);
        y_v=y_tmp(valid); x_v=x_tmp(valid); n_v=sum(valid);
        win_size=floor(0.8*n_v); T_win=n_v-win_size;
        if T_win<10, continue; end

        fprintf('    %-22s  ',commodity_names{c_idx});
        e_const=zeros(T_win,1); e_ar=zeros(T_win,1);
        e_tar=zeros(T_win,1);   e_cotar=zeros(T_win,1);

        for t=1:T_win
            y_tr=y_v(t:t+win_size-1); x_tr=x_v(t:t+win_size-1);
            y_te=y_v(t+win_size);
            yhat_const=mean(y_tr);
            [~,yhat_ar]=est_AR_v1(y_tr,p);
            res_tar=est_CoTAR_v3(y_tr,x_tr,p,ds,ms_list_tar,cutoff);
            if isempty(res_tar.beta_hat), yhat_tar=yhat_ar;
            else, yhat_tar=res_tar.y_hat_outsample; end
            res_co=est_CoTAR_v3(y_tr,x_tr,p,ds,ms,cutoff);
            if isempty(res_co.beta_hat), yhat_cotar=yhat_ar;
            else, yhat_cotar=res_co.y_hat_outsample; end
            e_const(t)=(y_te-yhat_const)^2; e_ar(t)=(y_te-yhat_ar)^2;
            e_tar(t)=(y_te-yhat_tar)^2;     e_cotar(t)=(y_te-yhat_cotar)^2;
        end

        rmse_c=sqrt(mean(e_const)); rmse_ar=sqrt(mean(e_ar));
        rmse_tar=sqrt(mean(e_tar)); rmse_co=sqrt(mean(e_cotar));
        d_dm=e_tar-e_cotar;
        pv_eq=dm_pval(d_dm,'two',T_win);
        pv_tar=dm_pval(d_dm,'left',T_win);
        pv_co=dm_pval(d_dm,'right',T_win);

        fprintf(fid,'%-22s  %-10s  %4d %5d  %12.3f %12.3f %12.3f %12.3f  %14.4f%3s %14.4f%3s %14.4f%3s\n', ...
                commodity_names{c_idx},gpr_names{g},n_v,T_win, ...
                rmse_c,rmse_ar,rmse_tar,rmse_co, ...
                pv_eq,strtrim(getsig(pv_eq)), ...
                pv_tar,strtrim(getsig(pv_tar)), ...
                pv_co,strtrim(getsig(pv_co)));
        fprintf(fid2,'%s,%s,%s,%d,%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%s,%s,%s\n', ...
                commodity_groups{c_idx},commodity_names{c_idx},gpr_names{g},n_v,T_win,win_size, ...
                rmse_c,rmse_ar,rmse_tar,rmse_co,pv_eq,pv_tar,pv_co, ...
                strtrim(getsig(pv_eq)),strtrim(getsig(pv_tar)),strtrim(getsig(pv_co)));
        fprintf('RMSE: const=%.3f AR=%.3f TAR=%.3f CoTAR=%.3f | p(eq)=%.3f%s\n', ...
                rmse_c,rmse_ar,rmse_tar,rmse_co,pv_eq,strtrim(getsig(pv_eq)));
    end
end
fprintf(fid,'\n%s\nNOTES: *** p<0.01 ** p<0.05 * p<0.10 | d(t)=MSE_TAR-MSE_CoTAR | DM Harvey (1997)\n',repmat('-',1,155));
fclose(fid);  fclose(fid2);
fprintf('  -> Table3b_RollingWindow_OOS.txt / .csv\n');

%% ── Save .mat ─────────────────────────────────────────────────────────────
save([output_dir 'Full_CoTAR_GPR_Results.mat'], ...
     'results_d','results_m','results_c', ...
     'results_alpha1','results_alpha2','results_phi1','results_phi2', ...
     'results_se1','results_se2','results_tstat1','results_tstat2', ...
     'results_pval1','results_pval2', ...
     'results_share1','results_share2','results_dur1','results_dur2', ...
     'results_trans11','results_trans22', ...
     'results_SSR_CoTAR','results_SSR_AR','results_R2_improv', ...
     'results_yhat_oos','results_pvals','results_waldstats','results_LMstats', ...
     'commodity_names','gpr_names','dates_aligned','n');
fprintf('  -> Full_CoTAR_GPR_Results.mat\n');

%% =========================================================================
%  SECTION 11: FIGURES
%  =========================================================================
fprintf('\nGenerating figures...\n');
set(0,'DefaultAxesFontName','Helvetica','DefaultTextFontName','Helvetica', ...
      'DefaultAxesFontSize',10,'DefaultLineLineWidth',1.2);

% Compute RV structs for each group
rv_pm = compute_rv_types(pm_raw, {'Gold','Silver','Platinum'}, dates_aligned);
rv_ag = compute_rv_types(ag_raw, {'Wheat','Sweetcorn','Soybean','Cotton','Cocoa','Coffee'}, dates_aligned);
rv_me = compute_rv_types(me_raw, {'Copper','Zinc','Nickel','Lead'}, dates_aligned);
rv_en = struct([]);

energy_names = {'WTI Crude Oil','Brent Crude','Natural Gas','RBOB Gasoline','Heating Oil'};

for i = 1:5
    rv_en(i).name  = energy_names{i};
    rv_en(i).dates = dates_aligned;
    rv_en(i).rv_tot  = NaN(size(dates_aligned));
    rv_en(i).rv_good = NaN(size(dates_aligned));
    rv_en(i).rv_bad  = NaN(size(dates_aligned));
end
all_rv = [rv_pm, rv_ag, rv_me, rv_en];
n_comm = numel(all_rv);

%% -- Figure 1: Log-RV Time Series --
rv_fields = {'rv_tot','rv_good','rv_bad'};
rv_labels = {'RV^{\pm}','RV^{+}','RV^{-}'};

fig1 = figure('Position',[50 50 1500 220*n_comm],'Visible','off');
for c_idx = 1:n_comm
    for rv_i = 1:3
        subplot(n_comm,3,(c_idx-1)*3+rv_i);
        y_pl = all_rv(c_idx).(rv_fields{rv_i});
        ok   = ~isnan(y_pl);
        plot(all_rv(c_idx).dates(ok), y_pl(ok), 'b-', 'LineWidth',0.8);
        title(sprintf('%s: %s', all_rv(c_idx).name, rv_labels{rv_i}),'FontSize',8,'FontWeight','bold');
        ylabel('log-RV','FontSize',7);
       d = all_rv(c_idx).dates(ok);   % IMPORTANT FIX

        % Remove invalid dates
        d = d(~isnat(d));
        
        if numel(d) >= 2
            dmin = min(d);
            dmax = max(d);
        
            if ~isnat(dmin) && ~isnat(dmax) && dmin < dmax
                xlim([dmin, dmax]);
            end
        end
        grid on; box on; set(gca,'FontSize',8);
    end
end
sgtitle(sprintf('Fig. 1.  Monthly Log-RV Time Series  (%s – %s)', date_start, date_end), ...
        'FontSize',12,'FontWeight','bold');
save_fig(fig1, output_dir, 'Figure1_LogRV_TimeSeries');
fprintf('  -> Figure 1\n');

%% -- Figure 2: CoTAR Conditional Threshold --
nrows = ceil(n_comm/3);
fig2  = figure('Position',[50 50 1600 310*nrows],'Visible','off');
for c_idx = 1:n_comm
    subplot(nrows,3,c_idx);
    cm_idx = find(strcmp(commodity_names, all_rv(c_idx).name), 1);
    if isempty(cm_idx), continue; end
    g=1;
    x_tmp=GPR_aligned(:,g); y_tmp=logRV_aligned(:,cm_idx);
    vld=~isnan(y_tmp)&~isnan(x_tmp);
    x_use=x_tmp(vld); d_v=dates_aligned(vld); n_use=sum(vld);
    dh=results_d(cm_idx,g); mh=results_m(cm_idx,g); ch=results_c(cm_idx,g);
    if isnan(mh) || isnan(ch) || mh < 1
        continue;
    end
    
    mc = round(mh * ch);
    
    if isnan(mc) || mc < 1
        mc = 1;
    elseif mc > mh
        mc = mh;
    end % guard against zero index when ch is very small
    mu=NaN(n_use,1);
    if mh <= 0 || isnan(mh)
        continue;
    end
    for t = mh:n_use
    
        if t - mh + 1 < 1
            continue;
        end
    
        cs = sort(x_use(t-mh+1:t));
    
        % --- SAFETY ---
        if isempty(cs) || length(cs) < mh
            continue;
        end
    
        % --- FINAL INDEX SAFETY ---
        if mc > length(cs)
            mc = length(cs);
        end
    
        mu(t) = cs(mc);
    end
    mu_lag=[NaN; mu(1:end-1)];
    hold off;
    plot(d_v,x_use,'b-','LineWidth',0.7); hold on;
    plot(d_v,mu_lag,'r-','LineWidth',1.8);
    title(sprintf('%s\n(d=%d,m=%d,c=%.2f)',all_rv(c_idx).name,dh,mh,ch),'FontSize',8,'FontWeight','bold');
    ylabel('log-GPR / threshold','FontSize',7);
    d_v = d_v(~isnat(d_v));

    if numel(d_v) >= 2
        xlim([min(d_v), max(d_v)]);
    end
    legend({'log(GPR)','\mu_{t-1}(\hat\gamma)'},'FontSize',6,'Location','northwest');
    grid on; box on; set(gca,'FontSize',8);
end
sgtitle({'Fig. 2.  CoTAR Conditional Threshold (GPR)','Blue: log(GPR)  |  Red: \mu_{t-1}(\hat{\gamma})'}, ...
        'FontSize',11,'FontWeight','bold');
save_fig(fig2, output_dir, 'Figure2_CoTAR_Threshold');
fprintf('  -> Figure 2\n');

%% -- Figure 3: TAR Constant Threshold --
fig3 = figure('Position',[50 50 1600 310*nrows],'Visible','off');
for c_idx = 1:n_comm
    subplot(nrows,3,c_idx);
    cm_idx = find(strcmp(commodity_names, all_rv(c_idx).name), 1);
    if isempty(cm_idx), continue; end
    g=1;
    x_tmp=GPR_aligned(:,g); y_tmp=logRV_aligned(:,cm_idx);
    vld=~isnan(y_tmp)&~isnan(x_tmp);
    x_use=x_tmp(vld); d_v=dates_aligned(vld);
    mu_hat=median(x_use);
    hold off; plot(d_v,x_use,'b-','LineWidth',0.7); hold on;
    yline(mu_hat,'r-','LineWidth',2.0);
    title(all_rv(c_idx).name,'FontSize',8,'FontWeight','bold');
    ylabel('log-GPR','FontSize',7); xlim([d_v(1) d_v(end)]);
    legend({'log(GPR)','\hat\mu (median)'},'FontSize',6,'Location','northwest');
    grid on; box on; set(gca,'FontSize',8);
end
sgtitle({'Fig. 3.  TAR Constant Threshold (GPR)','Blue: log(GPR)  |  Red: \hat\mu = median'}, ...
        'FontSize',11,'FontWeight','bold');
save_fig(fig3, output_dir, 'Figure3_TAR_Threshold');
fprintf('  -> Figure 3\n');

%% -- Figure 4: Hansen P-values --
fig4 = figure('Position',[100 100 1200 max(600, 30*num_commodities)],'Visible','off');
pv_supW = squeeze(results_pvals(:,:,1));
clrs = [0.20 0.47 0.75; 0.91 0.30 0.24; 0.18 0.70 0.33];
x_pos=(1:num_commodities)'; w=0.25;
hold on;
for g=1:num_gpr
    barh(x_pos+(g-2)*w, pv_supW(:,g), w, ...
         'FaceColor',clrs(g,:),'EdgeColor','k','FaceAlpha',0.85);
end
xline(0.10,'k--','LineWidth',1.5); xline(0.05,':','Color',[0.4 0.4 0.4],'LineWidth',1.5);
set(gca,'YTick',1:num_commodities,'YTickLabel',commodity_names,'FontSize',9);
xlabel('Bootstrap p-value (sup-Wald)','FontSize',11); xlim([0 1.05]);
legend([gpr_names,{'10% level','5% level'}],'Location','southeast','FontSize',9);
title({'Fig. 4.  Hansen Test: H_0 = No Threshold Effect (sup-Wald p-values)', ...
       'CoTAR model with log(GPR) as threshold'},'FontWeight','bold','FontSize',11);
grid on; box on;
save_fig(fig4, output_dir, 'Figure4_Hansen_Pvalues');
fprintf('  -> Figure 4\n');

%% -- Figure 5: R² Improvement --
fig5 = figure('Position',[100 100 1600 max(600, 35*num_commodities)],'Visible','off');
for g=1:num_gpr
    subplot(1,3,g);
    r2v=results_R2_improv(:,g);
    clr_bars=zeros(num_commodities,3);
    for c_idx=1:num_commodities
        if r2v(c_idx)>0, clr_bars(c_idx,:)=[0.20 0.65 0.25];
        else,             clr_bars(c_idx,:)=[0.85 0.25 0.20]; end
    end
    bh=barh(r2v); bh.FaceColor='flat'; bh.CData=clr_bars; hold on;
    pvc=squeeze(results_pvals(:,g,1));
    for c_idx=1:num_commodities
        if results_d(c_idx,g)>0
            s='';
            if pvc(c_idx)<0.01,s='***'; elseif pvc(c_idx)<0.05,s='**'; elseif pvc(c_idx)<0.10,s='*'; end
            if ~isempty(s)
                text(r2v(c_idx)+0.003,c_idx,s,'FontSize',8,'Color',[0 0 0.6],'FontWeight','bold');
            end
        end
    end
    xline(0,'k-','LineWidth',1.5);
    set(gca,'YTick',1:num_commodities,'YTickLabel',commodity_names,'FontSize',8);
    xlabel('\DeltaR^2 (CoTAR over AR)'); title(gpr_names{g},'FontWeight','bold','FontSize',11);
    xlim([-0.05 0.35]); grid on; box on;
end
sgtitle({'Fig. 5.  R^2 Improvement: CoTAR over AR Baseline', ...
         'Green = positive | Red = negative | Stars = sup-Wald sig.'}, ...
        'FontSize',12,'FontWeight','bold');
save_fig(fig5, output_dir, 'Figure5_R2_Improvement');
fprintf('  -> Figure 5\n');

%% =========================================================================
%  SECTION 12: CONSOLE SUMMARY
%  =========================================================================
fprintf('\n%s\nSUMMARY: Significant threshold effects (sup-Wald p < 0.10)\n%s\n', ...
        repmat('=',1,80), repmat('=',1,80));
fprintf('%-22s  %-12s  %6s %6s %6s  %8s  %8s\n', ...
        'Commodity','GPR_Type','d','m','c','DeltaR2','p(supW)');
fprintf('%s\n',repmat('-',1,80));
for g=1:num_gpr
    for c_idx=1:num_commodities
        pv=results_pvals(c_idx,g,1);
        if pv<0.10 && results_d(c_idx,g)>0
            s='*'; if pv<0.05,s='**'; end; if pv<0.01,s='***'; end
            fprintf('%-22s  %-12s  %6d %6d %6.4f  %8.4f  %8.4f %s\n', ...
                    commodity_names{c_idx},gpr_names{g}, ...
                    results_d(c_idx,g),results_m(c_idx,g),results_c(c_idx,g), ...
                    results_R2_improv(c_idx,g),pv,s);
        end
    end
end
fprintf('\nAll outputs saved to: %s\nDone.\n', output_dir);

%% =========================================================================
%  LOCAL HELPER FUNCTIONS
%% =========================================================================

function s = getsig(pv)
    if     pv < 0.01, s = '***';
    elseif pv < 0.05, s = '** ';
    elseif pv < 0.10, s = '*  ';
    else,             s = '   '; end
end

function pval = dm_pval(d, alt, T)
% Diebold-Mariano with Harvey et al. (1997) small-sample correction.
    db = mean(d);  g0 = var(d);
    if g0 == 0, pval=1; return; end
    adj = sqrt((T+1-2+1/T)/T);
    DM  = db/sqrt(g0/T)*adj;
    switch alt
        case 'two',   pval = 2*(1-normcdf(abs(DM)));
        case 'left',  pval = normcdf(DM);
        case 'right', pval = 1-normcdf(DM);
        otherwise,    pval = 2*(1-normcdf(abs(DM)));
    end
end

function tbl = load_price_table(filename, sheet, col_names, date_start, date_end)
% Load a price table, rename columns, sort by date, filter to window.
    raw = readtable(filename, 'Sheet', sheet, 'VariableNamingRule', 'preserve');
    % Assign clean column names
    for k = 1:numel(col_names)
        raw.Properties.VariableNames{k} = col_names{k};
    end
    % Parse date column
    dc = raw.Date;
    if ~isdatetime(dc)
        if isnumeric(dc)
            dc = datetime(dc, 'ConvertFrom', 'excel');
        else
            dc = datetime(string(dc));
        end
        raw.Date = dc;
    end
    raw = sortrows(raw, 'Date');
    mask = (raw.Date >= datetime(date_start)) & (raw.Date <= datetime(date_end));
    tbl = raw(mask, :);
end

function rv_structs = compute_rv_types(price_tbl, col_names, dates_aligned)
% Compute RV±, RV+, RV- for a list of commodities from a price table.
    n_aligned = numel(dates_aligned);
    tgt_ym    = year(dates_aligned)*100 + month(dates_aligned);
    K         = numel(col_names);
    rv_structs = repmat( ...
        struct('name','','dates',dates_aligned, ...
               'rv_tot',NaN(n_aligned,1),'rv_good',NaN(n_aligned,1),'rv_bad',NaN(n_aligned,1)), ...
        1, K);
    for k = 1:K
        rv_structs(k).name = col_names{k};
        prices = price_tbl.(col_names{k});
        prices(prices<=0) = NaN;
        lr  = diff(log(prices));
        r2  = lr.^2;  r2(r2==0)=NaN;
        rvt = log(r2);
        rvg = rvt;  rvg(lr<=0)=NaN;
        rvb = rvt;  rvb(lr>=0)=NaN;
        src_dates = price_tbl.Date(2:end);
        src_ym    = year(src_dates)*100 + month(src_dates);
        for ti = 1:n_aligned
            idx = find(src_ym == tgt_ym(ti), 1);
            if ~isempty(idx)
                rv_structs(k).rv_tot(ti)  = rvt(idx);
                rv_structs(k).rv_good(ti) = rvg(idx);
                rv_structs(k).rv_bad(ti)  = rvb(idx);
            end
        end
    end
end

function rv_structs = compute_rv_types_energy(en_raw, dates_aligned)
% Compute RV types for 5 energy commodities with full display names.
    int_keys = {'WTI_Crude_Oil','Brent_Crude','Natural_Gas','RBOB_Gasoline','Heating_Oil'};
    disp_names = {'WTI Crude Oil','Brent Crude','Natural Gas','RBOB Gasoline','Heating Oil'};
    K = numel(int_keys);
    n_aligned = numel(dates_aligned);
    tgt_ym    = year(dates_aligned)*100 + month(dates_aligned);
    rv_structs = repmat( ...
        struct('name','','dates',dates_aligned, ...
               'rv_tot',NaN(n_aligned,1),'rv_good',NaN(n_aligned,1),'rv_bad',NaN(n_aligned,1)), ...
        1, K);
    for k = 1:K
        rv_structs(k).name = disp_names{k};
        prices = en_raw.(int_keys{k});
        prices(prices<=0) = NaN;
        lr  = diff(log(prices));
        r2  = lr.^2;  r2(r2==0)=NaN;
        rvt = log(r2);
        rvg = rvt;  rvg(lr<=0)=NaN;
        rvb = rvt;  rvb(lr>=0)=NaN;
        src_dates = en_raw.Date(2:end);
        src_ym    = year(src_dates)*100 + month(src_dates);
        for ti = 1:n_aligned
            idx = find(src_ym == tgt_ym(ti), 1);
            if ~isempty(idx)
                rv_structs(k).rv_tot(ti)  = rvt(idx);
                rv_structs(k).rv_good(ti) = rvg(idx);
                rv_structs(k).rv_bad(ti)  = rvb(idx);
            end
        end
    end
end

function save_fig(fig, outdir, basename)
% Save figure as both PNG and EPS.
    try
        print(fig, fullfile(outdir, basename), '-dpng', '-r150');
        print(fig, fullfile(outdir, basename), '-depsc');
    catch ME_f
        warning('Figure save failed (%s): %s', basename, ME_f.message);
    end
    close(fig);
end
