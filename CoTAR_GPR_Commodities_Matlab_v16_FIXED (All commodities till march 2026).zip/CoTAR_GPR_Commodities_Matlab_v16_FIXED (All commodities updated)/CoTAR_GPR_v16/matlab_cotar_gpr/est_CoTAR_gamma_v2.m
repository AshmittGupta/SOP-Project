function [beta_hat, SSR, y_hat_outsample] = est_CoTAR_gamma_v2(y, x, p, gamma, cutoff)
% PURPOSE: Compute the conditional LS estimator of the Conditional 
%    Threshold Autoregressive (CoTAR) model given gamma.
%--------------------------------------------------------------------------
% USAGE: [beta_hat, SSR, y_hat_outsample] = est_CoTAR_gamma_v2(y, x, p, gamma, cutoff)
% where: y = target variable (n x 1)
%               n = sample size
%        x = threshold variable (n x 1)
%        p = AR lag length (1 x 1) 
%        gamma = [d; m; c] (3 x 1)
%               d = delay parameter 
%               m = memory size
%               c = percentile parameter (m*c must be an integer)
%        cutoff = cut-off value of the share of each regime (1 x 1)
%               If the shares of both regimes are above cutoff (say 0.15),
%                   then implement LS. Otherwise, assign SSR = inf.
%--------------------------------------------------------------------------
% RETURNS: beta_hat = [beta1_hat; beta2_hat] (K x 1)
%               where betar_hat = estimated AR parameters in regime r
%                     K = 2*(p+1)
%          SSR = sum of squared residuals (1 x 1)
%               The output SSR is useful for profiling estimation.
%          y_hat_outsample = 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)
%--------------------------------------------------------------------------
% Conditional Threshold Autoregressive (CoTAR) model: 
%     y(t) = alpha1 + SUM(phi1(k)*y(t-k)) + u(t)
%                if x(t-d) < mu(t-d-1; m, c)
%          = alpha2 + SUM(phi2(k)*y(t-k)) + u(t)
%                if x(t-d) >= mu(t-d-1; m, c)
%     mu(t; m, c) = (m*c)-th smallest value of {x(t), x(t-1), ..., x(t-m+1)}
%     beta1 = [alpha1, phi1(1), ..., phi1(p)]' 
%     beta2 = [alpha2, phi2(1), ..., phi2(p)]' 
%     beta = [beta1', beta2']' 
%     gamma = [d, m, c]'
%     When y = x, we have the self-exciting CoTAR (SE-CoTAR) model.
% -------------------------------------------------------------------------
% References: 
%     K. Motegi, J. W. Dennis, and S. Hamori (2024). Conditional Threshold 
%        Autoregression (CoTAR). SSRN Working Paper #3960058.
%     B. E. Hansen (1996). Inference When a Nuisance Parameter Is Not 
%        Identified Under the Null Hypothesis. Econometrica, vol. 64, 
%        pp. 413-430.
%--------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

n = length(y);     % sample size (1 x 1)
d = gamma(1);      % delay parameter (1 x 1)
m = gamma(2);      % memory size (1 x 1)
c = gamma(3);      % percentile parameter (1 x 1)
mc = min(m, max(1, round(m * c)));   % m*c must be >= 1 (guard against zero index)
K = 2*(p+1);       % # of regression parameters (1 x 1)    

% compute a conditional threshold
mu = zeros(n,1);
for t = m:n
     choice_set = x((t-m+1):t);    % choice set (m x 1)
     choice_set_sorted = sort(choice_set);    % sort from the smallest (m x 1)
     mu(t) = choice_set_sorted(mc);    % pick the mc-th smallest value (1 x 1)
end    

% judge whether each time period is in regime 1 or 2
I1 = zeros(n,1);
I1((m+1):n) = (x((m+1):n) < mu(m:(n-1)));    % I1(t) = 1 if time t lies in regime 1
I2 = zeros(n,1);
I2((m+1):n) = (x((m+1):n) >= mu(m:(n-1)));   % I2(t) = 1 if time t lies in regime 2

% share of each regime
share1 = mean(I1((m+1):n));    % share of regime 1 (1 x 1)
share2 = mean(I2((m+1):n));    % share of regime 2 (1 x 1)
if min(share1, share2) < cutoff    % too few observations in a regime
    beta_hat = [];
    SSR = inf; 
else    % enough observations in both regime
    n0 = max(p, m+d);   % # of initial observations discarded (1 x 1)
    nobs = n - n0;      % effective sample size (1 x 1 )
    Y = y((n0+1):n);    % regressand (nobs x 1)

    % construct regressors
    AR_lags_half = ones(nobs, p+1);
    if p >= 1
        for k = 1:p
             AR_lags_half(:,k+1) = y((n0+1-k):(n-k)); 
        end
    end    
    AR_lags = repmat(AR_lags_half, 1, 2);    % nobs x K
    I1_rep = repmat(I1((n0+1-d):(n-d)), 1, p+1);   % nobs x (p+1)
    I2_rep = repmat(I2((n0+1-d):(n-d)), 1, p+1);   % nobs x (p+1)
    I_rep = [I1_rep, I2_rep];    % nobs x 2*(p+1)
    Z = AR_lags .* I_rep;        % regressors (nobs x K)

    % least squares estimation
    beta_hat = Z \ Y;    % LS estimate (K x 1)
    u_hat = Y - Z * beta_hat;    % residual (nobs x 1)
    SSR = sum(u_hat.^2);    % sum of squared residuals (1 x 1)    
    
    % 1-step-ahead out-of-sample prediction for y(n+1)
    z_outsample = [1; flipud(y((n-p+1):n))];    % (p+1) x 1
    if x(n+1-d) < mu(n-d)    % period t = n+1 is in regime 1
        beta1_hat = beta_hat(1:(p+1));   % (p+1) x 1 
        y_hat_outsample = z_outsample' * beta1_hat;   % 1 x 1
    else      % period t = n+1 is in regime 2
        beta2_hat = beta_hat((p+2):K);   % (p+1) x 1 
        y_hat_outsample = z_outsample' * beta2_hat;   % 1 x 1
    end            
end    
    
end
