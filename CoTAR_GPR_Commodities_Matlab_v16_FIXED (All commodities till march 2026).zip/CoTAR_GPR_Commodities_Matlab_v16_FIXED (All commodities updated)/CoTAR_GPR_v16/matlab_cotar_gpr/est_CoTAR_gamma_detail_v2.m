function results = est_CoTAR_gamma_detail_v2(y, x, p, gamma, cutoff, hetero_flag, nomsize)
% PURPOSE: Compute the conditional LS estimator of the Conditional 
%    Threshold Autoregressive (CoTAR) model given gamma.
%--------------------------------------------------------------------------
% USAGE: results = est_CoTAR_gamma_detail_v2(y, x, p, gamma, cutoff, hetero_flag, nomsize)
% where: y = target variable (n x 1)
%               n = sample size
%        x = threshold variable (n x 1)
%        p = AR lag length (1 x 1)
%        gamma = [d; m; c] (3 x 1)
%               d = delay parameter 
%               m = memory size
%               c = percentile parameter (m*c must be an integer)
%        cutoff = cut-off value of the share of each regime (1 x 1)
%               If the shares of both regimes are above cutoff (say 0.15),
%                   then implement LS. Otherwise, assign SSR = inf.
%        hetero_flag = 1 if heteroscedasticity-robust covariance matrix is used
%                      0 if non-robust covariance matrix is used
%        nomsize = nominal size (1 x 1)
%                  used for t-test wrt zero restriction     
%--------------------------------------------------------------------------
% RETURNS: results = structure
%        results.hetero_flag = hetero_flag
%        results.nomsize = nomsize
%        results.beta_hat = LS estimator (K x 1)
%                where K = 2 * (p+1)
%        results.gamma = given nuisance parameter (3 x 1)
%        results.nobs = effective sample size (1 x 1)
%        results.sigsq_hat = error variance estimator (1 x 1)
%        results.V_hat = asymptotic covariance matrix (K x K)
%                        robust form is used if hetero_flag = 1
%                        non-robust form is used if hetero_flag = 0
%        results.se = standard error (K x 1)
%        results.tstat = t-statistics wrt zero restrictions (K x 1)
%        results.pval = two-sided p-values of the t-test (K x 1)
%        results.rflag = 1 if the zero restriction is rejected
%                        0 if it is accepted (K x 1)
%        results.cv = asymptotic critical value (1 x 1)
%        results.CI_lb = lower bound of 100*(1-nomsize)% confidence interval (K x 1)
%        results.CI_ub = upper bound of 100*(1-nomsize)% confidence interval (K x 1)
%        results.CI = 100*(1-nomsize)% confidence interval (K x 2) 
%        results.share1 = share of regime 1 to the entire sample size (1 x 1)
%        results.share2 = share of regime 2 to the entire sample size (1 x 1)
%        results.share11 = empirical transition probability from regime 1 to regime 1 (1 x 1)
%        results.share21 = empirical transition probability from regime 1 to regime 2 (1 x 1)
%        results.share12 = empirical transition probability from regime 2 to regime 1 (1 x 1)
%        results.share22 = empirical transition probability from regime 2 to regime 2 (1 x 1)
%        results.ave_duration1 = empirical average duration of regime 1 (1 x 1)
%        results.ave_duration2 = empirical average duration of regime 2 (1 x 1)
%        results.I1_vec = flags of regime 1 (nobs x 1) 
%        results.I2_vec = flags of regime 2 (nobs x 1) 
%        results.n0 = # of initial observations discarded (1 x 1)
%                     regimes of y((n0+1):n) are given by I1_vec and I2_vec
%        results.mu = conditional threshold (n x 1)
%        results.y_hat_outsample = 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)
%--------------------------------------------------------------------------
% Conditional Threshold Autoregressive (CoTAR) model: 
%     y(t) = alpha1 + SUM(phi1(k)*y(t-k)) + u(t)
%                if x(t-d) < mu(t-d-1; m, c)
%          = alpha2 + SUM(phi2(k)*y(t-k)) + u(t)
%                if x(t-d) >= mu(t-d-1; m, c)
%     mu(t; m, c) = (m*c)-th smallest value of {x(t), x(t-1), ..., x(t-m+1)}
%     beta1 = [alpha1, phi1(1), ..., phi1(p)]' 
%     beta2 = [alpha2, phi2(1), ..., phi2(p)]' 
%     beta = [beta1', beta2']' 
%     gamma = [d, m, c]'
%     When y = x, we have the self-exciting CoTAR (SE-CoTAR) model.
% -------------------------------------------------------------------------
% References: 
%     K. Motegi, J. W. Dennis, and S. Hamori (2024). Conditional Threshold 
%        Autoregression (CoTAR). SSRN Working Paper #3960058.
%     B. E. Hansen (1996). Inference When a Nuisance Parameter Is Not 
%        Identified Under the Null Hypothesis. Econometrica, vol. 64, 
%        pp. 413-430.
%--------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

% default set-up
if nargin == 5
    hetero_flag = 1;   % robust covariance matrix is used (1 x 1)
    nomsize = 0.05;    % nominal size (1 x 1)           
elseif nargin == 6
    nomsize = 0.05;    % nominal size (1 x 1) 
end    

n = length(y);    % sample size (1 x 1)
d = gamma(1);     % delay parameter (1 x 1)
m = gamma(2);     % memory size (1 x 1)
c = gamma(3);     % percentile parameter (1 x 1)
mc = min(m, max(1, round(m * c)));  % m*c must be >= 1 (guard against zero index)
K = 2*(p+1);      % dimension of beta (1 x 1)     

% compute a conditional threshold
mu = zeros(n,1);
for t = m:n
     choice_set = x((t-m+1):t);    % choice set (m x 1)
     choice_set_sorted = sort(choice_set);    % sort from the smallest (m x 1)
     mu(t) = choice_set_sorted(mc);    % pick the mc-th smallest value (1 x 1)
end    

% compare x and lagged mu to prepare a regime profile
% delay is not taken yet at this position
I1 = zeros(n,1);
I1((m+1):n) = (x((m+1):n) < mu(m:(n-1)));   % I1(t) = 1 if x(t) < mu(t-1)
I2 = zeros(n,1);
I2((m+1):n) = (x((m+1):n) >= mu(m:(n-1)));  % I2(t) = 1 if x(t) >= mu(t-1)

% share of each regime
share1 = mean(I1((m+1):n));   % share of regime 1 (1 x 1)
share2 = mean(I2((m+1):n));   % share of regime 2 (1 x 1)
if min(share1, share2) < cutoff   % too few observations in a regime
    results = [];
else    % enough observations in both regime
    % compute empirical transition probabilities
    share11_num = sum(I1((m+2):n) .* I1((m+1):(n-1)));   % 1 x 1
    share11_den = sum(I1((m+1):(n-1)));    % 1 x 1
    share11 = share11_num / share11_den;   % transition from regime 1 to regime 1
    share21 = 1 - share11;    % transition from regime 1 to regime 2
    share12_num = sum(I1((m+2):n) .* I2((m+1):(n-1)));   % 1 x 1
    share12_den = sum(I2((m+1):(n-1)));    % 1 x 1    
    share12 = share12_num / share12_den;   % transition from regime 2 to regime 1
    share22 = 1 - share12;    % transition from regime 2 to regime 2
    
    duration = [];
    counter = 0;
    for t = (m+1):n
         if I1(t) == 1
             counter = counter + 1;
             if t == n
                 duration = [duration; counter];              
             end    
         elseif I1(t) == 0
             if counter > 0
                 duration = [duration; counter];
             end    
             counter = 0;   % reset counter
         end    
    end    
    ave_duration1 = mean(duration);
    
    duration = [];
    counter = 0;
    for t = (m+1):n
         if I2(t) == 1
             counter = counter + 1;
             if t == n
                 duration = [duration; counter];              
             end    
         elseif I2(t) == 0
             if counter > 0
                 duration = [duration; counter];
             end    
             counter = 0;   % reset counter
         end    
    end    
    ave_duration2 = mean(duration);    
    
    n0 = max(p, m+d);   % # of initial observations discarded (1 x 1)
    nobs = n - n0;      % effective sample size (1 x 1 )
    Y = y((n0+1):n);    % regressand (nobs x 1)

    % construct regressors
    AR_lags_half = ones(nobs, p+1);
    if p >= 1
        for k = 1:p
             AR_lags_half(:,k+1) = y((n0+1-k):(n-k)); 
        end
    end    
    AR_lags = repmat(AR_lags_half, 1, 2);    % nobs x K
    I1_vec = I1((n0+1-d):(n-d));    % nobs x 1 
    I2_vec = I2((n0+1-d):(n-d));    % nobs x 1
    I1_rep = repmat(I1_vec, 1, p+1);    % nobs x (p+1)
    I2_rep = repmat(I2_vec, 1, p+1);    % nobs x (p+1)
    I_rep = [I1_rep, I2_rep];   % nobs x K
    Z = AR_lags .* I_rep;   % regressors (nobs x K)

    % least squares estimation and asymptotic t-test
    beta_hat = Z \ Y;    % LS estimator (K x 1)
    u_hat = Y - Z * beta_hat;   % residual (nobs x 1)
    SSR = sum(u_hat.^2);    % sum of squared residuals (1 x 1)    
    sigsq_hat = (1/nobs) * SSR;   % error variance estimator (1 x 1)
    
    M = (1/nobs) * (Z'*Z);  % K x K
    M_inv = M \ eye(K);     % K x K
    if hetero_flag == 0     % homoscedastic error
        V_hat = sigsq_hat * M_inv;    % non-robust covariance matrix (K x K)
    elseif hetero_flag == 1    % heteroscedastic error
        s_hat = Z .* repmat(u_hat, 1, K);     % regression score (nobs x K)
        S_hat = (1/nobs) * (s_hat' * s_hat);  % K x K
        V_hat = M_inv * S_hat * M_inv;    % robust covariance matrix (K x K)
    end    
    se = sqrt((1/nobs) * diag(V_hat));    % standard error (K x 1)
    tstat = beta_hat ./ se;     % t-statistics wrt zero restrictions (K x 1)
    pval = 2 * (1 - normcdf(abs(tstat)));   % two-sided p-values of the t-test (K x 1)
    rflag = (pval < nomsize);   % 1 if the zero restriction is rejected
                                % 0 if it is accepted (K x 1)
    cv = norminv(1 - 0.5*nomsize);  % asymptotic critical value (1 x 1)
    CI_lb = beta_hat - cv * se;     % lower bound of 100*(1-nomsize)% confidence interval (K x 1)
    CI_ub = beta_hat + cv * se;     % upper bound of 100*(1-nomsize)% confidence interval (K x 1)
    CI = [CI_lb, CI_ub];    % 100*(1-nomsize)% confidence interval (K x 2)
    
    % 1-step-ahead out-of-sample prediction for y(n+1)
    z_outsample = [1; flipud(y((n-p+1):n))];    % (p+1) x 1
    if x(n+1-d) < mu(n-d)    % period t = n+1 is in regime 1
        beta1_hat = beta_hat(1:(p+1));   % (p+1) x 1 
        y_hat_outsample = z_outsample' * beta1_hat;    % 1 x 1
    else      % period t = n+1 is in regime 2
        beta2_hat = beta_hat((p+2):K);   % (p+1) x 1 
        y_hat_outsample = z_outsample' * beta2_hat;    % 1 x 1
    end    
    
    % save results
    results.hetero_flag = hetero_flag;   % 1 if heteroscedasticity-robust covariance matrix is used
                                         % 0 if non-robust covariance matrix is used
    results.nomsize = nomsize;  % nominal size (1 x 1)
                                % used for t-test wrt zero restriction
    results.beta_hat = beta_hat;   % LS estimator (K x 1)
    results.gamma = gamma;   % given nuisance parameter (3 x 1)
    results.nobs = nobs;     % effective sample size (1 x 1)
    results.sigsq_hat = sigsq_hat;   % error variance estimator (1 x 1)
    results.V_hat = V_hat;   % asymptotic covariance matrix (K x K)
                             % robust form is used if hetero_flag = 1
                             % non-robust form is used if hetero_flag = 0
    results.se = se;   % standard error (K x 1)
    results.tstat = tstat;   % t-statistics wrt zero restrictions (K x 1)
    results.pval = pval;     % two-sided p-values of the t-test (K x 1)
    results.rflag = rflag;   % 1 if the zero restriction is rejected
                             % 0 if it is accepted (K x 1)
    results.cv = cv;   % asymptotic critical value (1 x 1)
    results.CI_lb = CI_lb;   % lower bound of 100*(1-nomsize)% confidence interval (K x 1)
    results.CI_ub = CI_ub;   % upper bound of 100*(1-nomsize)% confidence interval (K x 1)
    results.CI = CI;   % 100*(1-nomsize)% confidence interval (K x 2) 
    results.share1 = share1;     % share of regime 1 to the entire sample size (1 x 1)
    results.share2 = share2;     % share of regime 2 to the entire sample size (1 x 1)
    results.share11 = share11;   % empirical transition probability from regime 1 to regime 1 (1 x 1)
    results.share21 = share21;   % empirical transition probability from regime 1 to regime 2 (1 x 1)
    results.share12 = share12;   % empirical transition probability from regime 2 to regime 1 (1 x 1)
    results.share22 = share22;   % empirical transition probability from regime 2 to regime 2 (1 x 1)
    results.ave_duration1 = ave_duration1;   % empirical average duration of regime 1 (1 x 1)
    results.ave_duration2 = ave_duration2;   % empirical average duration of regime 2 (1 x 1)
    results.I1_vec = I1_vec;     % flags of regime 1 (nobs x 1) 
    results.I2_vec = I2_vec;     % flags of regime 2 (nobs x 1) 
    results.n0 = n0;   % # of initial observations discarded (1 x 1)
                       % regimes of y((n0+1):n) are given by I1_vec and I2_vec
    results.mu = mu;   % conditional threshold (n x 1)
    results.y_hat_outsample = y_hat_outsample;    % 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)    
end    
    
end
