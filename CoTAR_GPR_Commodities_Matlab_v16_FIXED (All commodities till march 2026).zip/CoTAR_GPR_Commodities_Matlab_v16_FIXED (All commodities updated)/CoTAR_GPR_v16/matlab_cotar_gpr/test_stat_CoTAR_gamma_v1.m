function results = test_stat_CoTAR_gamma_v1(y, x, p, gamma, cutoff, hetero_flag, R, q)
% PURPOSE: Compute Wald and LM test statistics wrt. a general linear 
%     parametric restriction based on CoTAR model given gamma.
%--------------------------------------------------------------------------
% USAGE: results = test_stat_CoTAR_gamma_v1(y, x, p, gamma, cutoff, hetero_flag, R, q)
% where: y = target variable (n x 1)
%               n = sample size
%        x = threshold variable (n x 1)
%        p = AR lag length (1 x 1) 
%        gamma = [d; m; c] (3 x 1)
%               d = delay parameter 
%               m = memory size
%               c = percentile parameter (m*c must be an integer)
%        cutoff = cut-off value of the share of each regime (1 x 1)
%               If the shares of both regimes are above cutoff (say 0.15),
%                   then compute everything. Otherwise, compute nothing.
%        hetero_flag = 1 if heteroscedasticity-robust covariance matrix is used
%                      0 if non-robust covariance matrix is used
%                      (default: hetero_flag = 1)
%        R = selection matrix (nrest x K)
%                nrest = # of parametric restrictions
%                K = 2 * (p+1) = # of regressors
%                (default: R = [eye(p+1), -eye(p+1)])
%        q = hypothesis values (nrest x 1)
%                (default: q = zeros(nrest,1))
%--------------------------------------------------------------------------
% RETURNS: results = structure
%        results.share_flag = 1 if the shares of both regimes are above cutoff
%                             0 otherwise
%        results.wald_stat = actual Wald statistic (1 x 1)
%        results.LM_stat = actual LM statistic (1 x 1)
%        results.boot_wald_stat_core = core part of bootstrap Wald statistic (K x K)
%        results.s_tilde = regression score under H0 (nobs x K)
%              where nobs = n - max(p, m+d) = effective sample size
%        results.s_hat = regression score under H1 (nobs x K)
%        results.boot_LM_stat_core = core part of bootstrap LM statistic (K x K)
%--------------------------------------------------------------------------
% Conditional Threshold Autoregressive (CoTAR) model: 
%     y(t) = alpha1 + SUM(phi1(k)*y(t-k)) + u(t)
%                if x(t-d) < mu(t-d-1; m, c)
%          = alpha2 + SUM(phi2(k)*y(t-k)) + u(t)
%                if x(t-d) >= mu(t-d-1; m, c)
%     mu(t; m, c) = (m*c)-th smallest value of {x(t), x(t-1), ..., x(t-m+1)}
%     beta1 = [alpha1, phi1(1), ..., phi1(p)]' 
%     beta2 = [alpha2, phi2(1), ..., phi2(p)]' 
%     beta = [beta1', beta2']' 
%     gamma = [d, m, c]'
%     When y = x, we have the self-exciting CoTAR (SE-CoTAR) model.
%--------------------------------------------------------------------------
% H0: R * beta = q
%   [Special case #1] 
%      No threshold effects: beta1 = beta2 
%      R = [eye(p+1), -eye(p+1)], q = zeros(p+1,1).
%      In this case, gamma is not identified.
%   [Special case #2] 
%      Single zero restriction: beta(i) = 0 for a certain i = 1, ..., K 
%      R = 1 x K vector whose i-th element is 1 and all other elements are 0.
%      q = 0.
% -------------------------------------------------------------------------
% NOTE: The outputs are required for computing the bootstrap p-value.
%       See Hansen_test_CoTAR_v2.m for the bootstrap procedure.
% -------------------------------------------------------------------------
% References: 
%     K. Motegi, J. W. Dennis, and S. Hamori (2024). Conditional Threshold 
%        Autoregression (CoTAR). SSRN Working Paper #3960058.
%     B. E. Hansen (1996). Inference When a Nuisance Parameter Is Not 
%        Identified Under the Null Hypothesis. Econometrica, vol. 64, 
%        pp. 413-430.
%     K. M. Abadir and J. R. Magnus (2005). Matrix Algebra. New York, NY: 
%        Cambridge University Press.
%     R. Davidson and J. G. MacKinnon (2004). Econometric Theory and  
%        Methods. New York, NY: Oxford University Press.  
%--------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

% default set-up
if nargin == 5
    hetero_flag = 1;    % robust covariance matrix is used
    R = [eye(p+1), -eye(p+1)];  % selection matrix ((p+1) x K)
    q = zeros(p+1,1);   % hypothesis values ((p+1) x 1)
elseif nargin == 6
    R = [eye(p+1), -eye(p+1)];  % selection matrix ((p+1) x K)
    q = zeros(p+1,1);   % hypothesis values ((p+1) x 1)
elseif nargin == 7
    q = zeros(size(R,1),1);   % hypothesis values (nrest x 1)         
end    

n = length(y);    % sample size (1 x 1)
d = gamma(1);     % delay parameter (1 x 1)
m = gamma(2);     % memory size (1 x 1)
c = gamma(3);     % percentile parameter (1 x 1)
mc = min(m, max(1, round(m * c)));% m*c must be >= 1 (guard against zero index)

% compute a conditional threshold 
mu = zeros(n,1);
for t = m:n
     choice_set = x((t-m+1):t);    % choice set (m x 1)
     choice_set_sorted = sort(choice_set);    % sort from the smallest (m x 1)
     mu(t) = choice_set_sorted(mc);    % pick the mc-th smallest value (1 x 1)
end    

% judge whether each time period is in regime 1 or 2
I1 = zeros(n,1);
I1((m+1):n) = (x((m+1):n) < mu(m:(n-1)));   % I1(t) = 1 if time t lies in regime 1
I2 = zeros(n,1);
I2((m+1):n) = (x((m+1):n) >= mu(m:(n-1)));  % I2(t) = 1 if time t lies in regime 2

% share of each regime
share1 = mean(I1((m+1):n));   % share of regime 1 (1 x 1)
share2 = mean(I2((m+1):n));   % share of regime 2 (1 x 1)
if min(share1, share2) < cutoff    % too few observations in a regime
    share_flag = 0;
    wald_stat = [];                     
    LM_stat = [];                      
    boot_wald_stat_core = [];   
    s_tilde = [];                           
    s_hat = [];                              
    boot_LM_stat_core = [];       
else
    share_flag = 1;
    K = 2 * (p+1);     % # of regressors (1 x 1) 
    n0 = max(p, m+d);  % # of initial observations discarded (1 x 1)
    nobs = n - n0;     % effective sample size (1 x 1)
    Y = y((n0+1):n);   % regressand (nobs x 1)

    % construct regressors
    AR_lags_half = ones(nobs, p+1);
    if p >= 1
        for k = 1:p
             AR_lags_half(:,k+1) = y((n0+1-k):(n-k)); 
        end
    end    
    AR_lags = repmat(AR_lags_half, 1, 2);    % nobs x K
    I1_rep = repmat(I1((n0+1-d):(n-d)), 1, p+1);   % nobs x (p+1)
    I2_rep = repmat(I2((n0+1-d):(n-d)), 1, p+1);   % nobs x (p+1)
    I_rep = [I1_rep, I2_rep];   % nobs x K
    Z = AR_lags .* I_rep;       % regressors (nobs x K)

    % LS estimation under H1
    beta_hat = Z \ Y;   % LS estimate (K x 1)
    u_hat = Y - Z * beta_hat;   % residual (nobs x 1)
    s_hat = Z .* repmat(u_hat, 1, K);   % regression score under H1 (nobs x K)

    % Wald test
    nrest = size(R,1);     % # of parametric restrictions (1 x 1)
    M = (1/n) * (Z' * Z);  % K x K
    M_inv = M \ eye(K);    % K x K
    if hetero_flag == 0    % homoscedastic error is assumed
        sigsq_hat = (1/n) * sum(u_hat.^2);   % 1 x 1
        V_hat = sigsq_hat * M_inv;    % non-robust covariance matrix (K x K)
    elseif hetero_flag == 1    % heteroscedastic error is possible
        S_hat = (1/n) * (s_hat' * s_hat);    % K x K
        V_hat = M_inv * S_hat * M_inv;       % robust covariance matrix (K x K)
    end    
    RV_hatR = R * V_hat * R';  % nrest x nrest
    RV_hatR_inv = RV_hatR \ eye(nrest);   % nrest x nrest
    deviation = R * beta_hat - q;    % nrest x 1
    wald_stat = n * deviation' * RV_hatR_inv * deviation;   % Wald statistic (1 x 1)   
 
    % compute a core part of bootstrapped Wald statistics
    RM_inv = R * M_inv;    % nrest x K
    boot_wald_stat_core = RM_inv' * RV_hatR_inv * RM_inv;   % K x K    
    
    % Exercise 4.8 of Davidson and MacKinnon (2004) ensures that there exists 
    % an order of R = [R1, R2] such that R2 is invertible; find such an order.
    % It suffices to try all combinations for choosing nrest columns out of nparam columns,
    % essentially because any interchange of columns of a (non-)singular matrix 
    % results in a (non-)singular matrix (Exercises 4.21, 4.32, 4.43, Abadir and Magnus, 2005).
    ncomb = nchoosek(K, nrest);    % # of combinations for choosing nrest columns out of K columns (1 x 1)
    R2_indexmat = nchoosek(1:K, nrest);    % all combinations (ncomb x nrest)
    for i = 1:ncomb
         R2_indexvec = R2_indexmat(i,:);   % fix a combination (1 x nrest)
         R2 = R(:,R2_indexvec);    % tentative R2 (nrest x nrest)
         R2_rank = rank(R2);   % rank of tentative R2 (1 x 1)
         if R2_rank == nrest   % tentative R2 is invertible
             R1 = R(:, ismember(1:K, R2_indexvec)==0);   % construct R1 (nrest x (K-nrest))
             R = [R1, R2];     % reordered selection matrix (nrest x K)
             Z1 = Z(:, ismember(1:K, R2_indexvec)==0);   % construct Z1 (nobs x (K-nrest))
             Z2 = Z(:, R2_indexvec);   % construct Z2 (nobs x nrest)
             Z = [Z1, Z2];     % reordered regressors (nobs x K)
             break;   % get out of the loop 
         end    
    end     
    
    % Note that R and Z may have been reordered
    R2_inv = R2 \ eye(nrest);      % nrest x nrest
    Y_new = Y - Z2 * R2_inv * q;   % nobs x 1
    Z_new = Z1 - Z2 * R2_inv * R1;   % nobs x (K-nrest)
    beta1_tilde = Z_new \ Y_new;   % restricted estimator ((K-nrest) x 1)
    u_tilde = Y_new - Z_new * beta1_tilde;   % residual (nobs x 1)
    s_tilde = Z .* repmat(u_tilde, 1, K);    % regression score under H0 (nobs x K)
    
    % compute LM statistic
    M = (1/n) * (Z' * Z);  % K x K
    M_inv = M \ eye(K);    % K x K
    if hetero_flag == 0    % homoscedastic error is assumed
        sigsq_tilde = (1/n) * sum(u_tilde.^2);   % 1 x 1
        V_tilde = sigsq_tilde * M_inv;   % non-robust covariance matrix (K x K)
    elseif hetero_flag == 1    % heteroscedastic error is possible
        S_tilde = (1/n) * (s_tilde' * s_tilde);  % K x K    
        V_tilde = M_inv * S_tilde * M_inv;   % robust covariance matrix (K x K)
    end
    RV_tildeR = R * V_tilde * R';   % nrest x nrest
    RV_tildeR_inv = RV_tildeR \ eye(nrest);  % nrest x nrest
    LM_stat = n * deviation' * RV_tildeR_inv * deviation;  % LM statistic (1 x 1)
                                                           % deviation does not need to be reordered

    % compute a core part of bootstrap LM statistics
    RM_inv = R * M_inv;   % nrest x K
    boot_LM_stat_core = RM_inv' * RV_tildeR_inv * RM_inv;  % K x K
end

% save important quantities
results.share_flag = share_flag;   % 1 if the shares of both regimes are above cutoff; 0 otherwise
results.wald_stat = wald_stat;   % actual Wald statistic (1 x 1)
results.LM_stat = LM_stat;   % actual LM statistic (1 x 1)
results.boot_wald_stat_core = boot_wald_stat_core;   % core part of bootstrap Wald statistic (K x K)
results.s_tilde = s_tilde;   % regression score under H0 (nobs x K)
results.s_hat = s_hat;   % regression score under H1 (nobs x K)
results.boot_LM_stat_core = boot_LM_stat_core;   % core part of bootstrap LM statistic (K x K)

end
