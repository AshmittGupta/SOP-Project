function [beta_hat, y_hat_outsample] = est_AR_v1(y, p)
% PURPOSE: Compute the least squares estimator of AR(p) with intercept
%    and perform 1-step-ahead out-of-sample prediction for y(n+1).
%--------------------------------------------------------------------------
% USAGE: [beta_hat, y_hat_outsample] = est_AR_v1(y, p)
% where: y = target variable (n x 1)
%               n = sample size
%        p = AR lag length (1 x 1); p is allowed to take 0 
%--------------------------------------------------------------------------
% RETURNS: beta_hat = OLS estimator for regression parameters ((p+1) x 1)
%     y_hat_outsample = 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)
%--------------------------------------------------------------------------
% Autoregression (AR): 
%     y(t) = alpha + SUM(phi(k)*y(t-k)) + u(t),
%     t = 1, ..., n,
%     beta = [alpha, phi(1), ..., phi(p)]' 
%     When p = 0, we have an intercept-only model. 
% -------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

n = size(y,1);   % sample size (1 x 1)
nobs = n - p;    % effective sample size (1 x 1)
X = ones(nobs, p+1);    % construct regressors (nobs x (p+1))
for k = 1:p      % If p = 0, this loop is skipped
     X(:,k+1) = y((p+1-k):(n-k));
end    
beta_hat = X \ y((p+1):n);    % OLS estimator ((p+1) x 1) 
Z = [1, fliplr(y((n-p+1):n)')];   % regressor for 1-step-ahead out-of-sample prediction for y(n+1) (1 x (p+1))
y_hat_outsample = Z * beta_hat;   % 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)

end
