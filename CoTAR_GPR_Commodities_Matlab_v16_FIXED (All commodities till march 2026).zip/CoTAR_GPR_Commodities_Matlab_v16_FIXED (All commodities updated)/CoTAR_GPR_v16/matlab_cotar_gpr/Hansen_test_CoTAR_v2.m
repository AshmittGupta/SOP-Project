function pvals = Hansen_test_CoTAR_v2(y, x, p, ds, ms, B, cutoff, hetero_flag, R, q)
% PURPOSE: Implement the wild-bootstrap Wald and LM tests wrt. 
%    a general linear parametric restriction based on the CoTAR model.
%--------------------------------------------------------------------------
% USAGE: pvals = Hansen_test_CoTAR_v2(y, x, p, ds, ms, B, cutoff, hetero_flag, R, q)
% where: y = target variable (n x 1)
%               n = sample size
%        x = threshold variable (n x 1)
%        p = AR lag length (1 x 1)
%        ds = candidate values of delay parameter (num_d x 1)
%            num_d = # of candidate values of delay parameter 
%        ms = candidate values of memory size (num_m x 1)
%            num_m = # of candidate values of memory size 
%        B = # of bootstrap samples (1 x 1)
%        cutoff = cut-off value of the share of each regime (1 x 1)
%               If the shares of both regimes are above cutoff (say 0.15),
%                   then take that gamma. Otherwise, discard it.
%        hetero_flag = 1 if heteroscedasticity-robust covariance matrix is used
%                      0 if non-robust covariance matrix is used
%                      (default: hetero_flag = 1)
%        R = selection matrix (nrest x K)
%                nrest = # of parametric restrictions
%                K = 2 * (p+1) = # of regressors
%                (default: R = [eye(p+1), -eye(p+1)], i.e. no-threshold-effect hypothesis)
%        q = hypothesis values (nrest x 1)
%                (default: q = zeros(nrest,1))
%--------------------------------------------------------------------------
% RETURNS: pvals = p-values (6 x 1) 
%        pvals(1) = bootstrap p-value of the sup-Wald test 
%        pvals(2) = bootstrap p-value of the ave-Wald test
%        pvals(3) = bootstrap p-value of the exp-Wald test
%        pvals(4) = bootstrap p-value of the sup-LM test 
%        pvals(5) = bootstrap p-value of the ave-LM test
%        pvals(6) = bootstrap p-value of the exp-LM test
%--------------------------------------------------------------------------
% Conditional Threshold Autoregressive (CoTAR) model: 
%     y(t) = alpha1 + SUM(phi1(k)*y(t-k)) + u(t)
%                if x(t-d) < mu(t-d-1; m, c)
%          = alpha2 + SUM(phi2(k)*y(t-k)) + u(t)
%                if x(t-d) >= mu(t-d-1; m, c)
%     mu(t; m, c) = (m*c)-th smallest value of {x(t), x(t-1), ..., x(t-m+1)}
%     beta1 = [alpha1, phi1(1), ..., phi1(p)]' 
%     beta2 = [alpha2, phi2(1), ..., phi2(p)]' 
%     beta = [beta1', beta2']' 
%     gamma = [d, m, c]'
%     When y = x, we have the self-exciting CoTAR (SE-CoTAR) model.
% -------------------------------------------------------------------------
% H0: R * beta = q
%   [Special case #1] 
%      No threshold effects: beta1 = beta2 
%      R = [eye(p+1), -eye(p+1)], q = zeros(p+1,1).
%      In this case, gamma is not identified.
%   [Special case #2] 
%      Single zero restriction: beta(i) = 0 for a certain i = 1, ..., K 
%      R = 1 x K vector whose i-th element is 1 and all other elements are 0.
%      q = 0.
% -------------------------------------------------------------------------
% See also: test_stat_CoTAR_gamma_v1.m
% -------------------------------------------------------------------------
% References: 
%     K. Motegi, J. W. Dennis, and S. Hamori (2024). Conditional Threshold 
%        Autoregression (CoTAR). SSRN Working Paper #3960058.
%     B. E. Hansen (1996). Inference When a Nuisance Parameter Is Not 
%        Identified Under the Null Hypothesis. Econometrica, vol. 64, 
%        pp. 413-430.
%--------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

% default set-up
if nargin == 7
    hetero_flag = 1;    % robust covariance matrix is used
    R = [eye(p+1), -eye(p+1)];   % selection matrix ((p+1) x K)
    q = zeros(p+1,1);   % hypothesis values ((p+1) x 1)
elseif nargin == 8
    R = [eye(p+1), -eye(p+1)];   % selection matrix ((p+1) x K)
    q = zeros(p+1,1);   % hypothesis values ((p+1) x 1)
elseif nargin == 9
    q = zeros(size(R,1),1);   % hypothesis values (nrest x 1)         
end    

n = length(y);   % sample size (1 x 1)
K = 2 * (p+1);   % # of regressors (1 x 1)

% construct a matrix which aligns all possible pairs of (m,c)
% If ms = [1, 2, 3], then mcs is constucted as follows.
% mcs = [1, 1/1;
%        2, 1/2;
%        2, 2/2;
%        3, 1/3;
%        3, 2/3;
%        3, 3/3]
num_m = length(ms);   % # of candidate values of m
mcs = [];
for i = 1:num_m
     m = ms(i);    % 1 x 1
     cs = (1/m)*(1:m)';   % m x 1
     mcs = [mcs; m*ones(m,1), cs];
end    
num_mcs = size(mcs,1);    % # of all possible pairs of (m,c) (1 x 1)

% construct a matrix which aligns all possible combinations of gamma = (d,m,c)'
% If ds = [1, 2] and ms = [1, 2, 3], then gammas is constructed as follows.
% gammas = [1, 1, 1/1;
%           1, 2, 1/2;
%           1, 2, 2/2;
%           1, 3, 1/3;
%           1, 3, 2/3;
%           1, 3, 3/3;
%           2, 1, 1/1;
%           2, 2, 1/2;
%           2, 2, 2/2;
%           2, 3, 1/3;
%           2, 3, 2/3;
%           2, 3, 3/3]
num_d = length(ds);    % # of candidate values of d
gammas = [];
for i = 1:num_d
     d = ds(i);    % 1 x 1
     gammas = [gammas; d*ones(num_mcs,1), mcs];
end    
num_gamma = size(gammas,1);   % # of all possible combinations of gamma (1 x 1)
rng(0,'v5normal');
ximat = randn(n,B);    % nobs x 1
share_flags = zeros(num_gamma,1);
wald_stats = zeros(num_gamma,1);
LM_stats = zeros(num_gamma,1);
boot_wald_stats = zeros(num_gamma, B);
boot_LM_stats = zeros(num_gamma, B);
for g = 1:num_gamma
     gamma = gammas(g,:)';   % fix gamma (3 x 1)    
     d = gamma(1);   % delay parameter
     m = gamma(2);   % memory size
     nobs = n - max(p, m+d);   % effective sample size (1 x 1)
      
     % compute test statistics given gamma
     results = test_stat_CoTAR_gamma_v1(y, x, p, gamma, cutoff, hetero_flag, R, q);
     share_flag = results.share_flag;   % 1 if the shares of both regimes are above cutoff; 0 otherwise
     share_flags(g) = share_flag;
     if share_flag == 1             
         wald_stat = results.wald_stat;   % actual Wald statistic (1 x 1)
         LM_stat = results.LM_stat;   % actual LM statistic (1 x 1)
         boot_wald_stat_core = results.boot_wald_stat_core;   % core part of bootstrapped Wald statistic (K x K)
         s_tilde = results.s_tilde;   % regression score under H0 (nobs x K)
         s_hat = results.s_hat;   % regression score under H1 (nobs x K)
         boot_LM_stat_core = results.boot_LM_stat_core;    % core part of bootstrapped LM statistic (K x K)

         % save test statistics 
         wald_stats(g) = wald_stat;
         LM_stats(g) = LM_stat;

         % compute bootstrapped Wald and LM test statistics for each gamma
         for b = 1:B
              xi = ximat(1:nobs, b);
              Xi = repmat(xi, 1, K);   % nobs x K
              v_tilde_star = n^(-0.5) * sum(s_tilde .* Xi)';   % K x 1
              v_hat_star = n^(-0.5) * sum(s_hat .* Xi)';   % K x 1
              boot_wald_stat = v_hat_star' * boot_wald_stat_core * v_hat_star;  % 1 x 1
              boot_wald_stats(g,b) = boot_wald_stat;
              boot_LM_stat = v_tilde_star' * boot_LM_stat_core * v_tilde_star;  % 1 x 1
              boot_LM_stats(g,b) = boot_LM_stat;
         end    
     end
end

% discard gammas under which the share of a regime is below cutoff
wald_stats = wald_stats(share_flags == 1);
LM_stats = LM_stats(share_flags == 1);
boot_wald_stats = boot_wald_stats(share_flags == 1, :);
boot_LM_stats = boot_LM_stats(share_flags == 1, :);

% sup-Wald test
sup_wald_stat = max(wald_stats);   % actual sup-Wald test statistic (1 x 1)
boot_sup_wald_stats = max(boot_wald_stats, [], 1)';   % bootstrap sup-Wald test statistics (B x 1)
pval_sup_wald = mean(boot_sup_wald_stats >= sup_wald_stat);   % bootstrap p-value based on the sup-Wald statistic (1 x 1)

% ave-Wald test
ave_wald_stat = mean(wald_stats);    % actual ave-Wald test statistic (1 x 1)
boot_ave_wald_stats = mean(boot_wald_stats, 1)';    % bootstrap ave-Wald test statistics (B x 1)
pval_ave_wald = mean(boot_ave_wald_stats >= ave_wald_stat);   % bootstrap p-value based on the ave-Wald statistic (1 x 1)

% exp-Wald test
exp_wald_stat = log(mean(exp(0.5 * wald_stats)));   % actual exp-Wald test statistic (1 x 1)
boot_exp_wald_stats = log(mean(exp(0.5 * boot_wald_stats), 1))';  % bootstrap exp-Wald test statistics (B x 1)
pval_exp_wald = mean(boot_exp_wald_stats >= exp_wald_stat);   % bootstrap p-value based on the exp-Wald statistic (1 x 1)

% sup-LM test
sup_LM_stat = max(LM_stats);    % actual sup-LM test statistic (1 x 1)
boot_sup_LM_stats = max(boot_LM_stats, [], 1)';    % bootstrap sup-LM test statistics (B x 1)
pval_sup_LM = mean(boot_sup_LM_stats >= sup_LM_stat);    % bootstrap p-value based on the sup-LM statistic (1 x 1)

% ave-LM test
ave_LM_stat = mean(LM_stats);    % actual ave-LM test statistic (1 x 1)
boot_ave_LM_stats = mean(boot_LM_stats, 1)';    % bootstrap ave-LM test statistics (B x 1)
pval_ave_LM = mean(boot_ave_LM_stats >= ave_LM_stat);   % bootstrap p-value based on the ave-LM statistic (1 x 1)

% exp-LM test
exp_LM_stat = log(mean(exp(0.5 * LM_stats)));   % actual exp-LM test statistic (1 x 1)
boot_exp_LM_stats = log(mean(exp(0.5 * boot_LM_stats), 1))';   % bootstrap exp-LM test statistics (B x 1)
pval_exp_LM = mean(boot_exp_LM_stats >= exp_LM_stat);   % bootstrap p-value based on the exp-LM statistic (1 x 1)

% collect p-values
pvals_wald = [pval_sup_wald, pval_ave_wald, pval_exp_wald]';   % 3 x 1
pvals_LM = [pval_sup_LM, pval_ave_LM, pval_exp_LM]';   % 3 x 1
pvals = [pvals_wald', pvals_LM']';    % 6 x 1
