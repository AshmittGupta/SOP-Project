function [test_stats, pvalues] = DM1995_asy_test_v3(loss_diff, horizon, H1_type)
% PURPOSE: Perform Diebold and Mariano's (1995) asymptotic tests on equal 
%     out-of-sample forecast accuracy
%--------------------------------------------------------------------------
% USAGE: [test_stats, pvalues] = DM1995_asy_test_v3(loss_diff, horizon, H1_type)
% where: loss_diff = differences in loss functions (T x 1)
%             where T = sample size
%        horizon = prediction horizon (1 x 1)
%        H1_type = 1 if H1: loss1 ~= loss2 (the accuracy of two forecasts is not the same)
%                         A two-sided test is implemented, and a rejection of H0 
%                         implies that the two forecasts have different accuracies.
%                  2 if H1: loss1 < loss2 (first forecast is more accurate than the second)
%                         A one-sided test is implemented, and a rejection of H0 
%                         implies that the first forecast is more accurate than the second.
%                  3 if H1: loss1 > loss2 (second forecast is more accurate than the first)
%                         A one-sided test is implemented, and a rejection of H0 
%                         implies that the second forecast is more accurate than the first.
%--------------------------------------------------------------------------
% RETURNS: test_stats = test statistics (3 x 1)
%             test_stat(1) = S1: mean test statistic 
%             test_stat(2) = S2a: sign test statistic
%             test_stat(3) = S3a: Wilcoxon's signed-rank test statistic
%          pvalues = asymptotic p-values (3 x 1)
%             pvalues(1) = p-value of S1 test 
%             pvalues(2) = p-value of S2a test 
%             pvalues(3) = p-value of S3a test 
%             All three test statistics follow N(0,1) under H0
%             (equal predictive accuracy). If pvalue < alpha, then reject H0 
%             at the 100*alpha% level in favor of H1.
%--------------------------------------------------------------------------
% Note: horizon is relevant for S1 test but not for S2a and S3a tests.
% -------------------------------------------------------------------------
% References: 
%     F. X. Diebold and R. S. Mariano (1995). Comparing predictive accuracy.
%        Journal of Business & Economic Statistics, vol. 13, pp. 253-263.
% -------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

% S1 test: mean test
T = length(loss_diff);   % sample size (1 x 1)
d_bar = (1/T) * sum(loss_diff);   % mean loss differential (1 x 1)
maxlag = T - 1;   % maximum lag length (1 x 1)
nlags = 2*maxlag + 1;    % 1 x 1

% compute sample variance and autocovariances of loss differential
gamma0_hat = (1/T) * sum((loss_diff - d_bar).^2);    % 1 x 1
gamma_hats_half = zeros(maxlag,1);
for tau = 1:maxlag
     loss_diff_lead = loss_diff((tau+1):T);
     loss_diff_lag = loss_diff(1:(T-tau));
     gamma_hats_half(tau) = (1/T) * sum((loss_diff_lead - d_bar).*(loss_diff_lag - d_bar));
end    
gamma_hats = [flipud(gamma_hats_half)', gamma0_hat, gamma_hats_half']';    % nlags x 1

% compute weights on sample autocovariances
if horizon == 1
    weights = [zeros(1,maxlag), 1, zeros(1,maxlag)]';    % nlags x 1
elseif horizon > 1
    tau_vec = (-maxlag):maxlag;    % 1 x nlags
    weights = zeros(nlags,1);   % nlags x 1
    for i = 1:nlags
         tau = tau_vec(i);
         if abs(tau / (horizon-1)) <= 1
             weights(i) = 1;
         else    
             weights(i) = 0; 
         end       
    end        
end    
asyvar = sum(weights .* gamma_hats);   % asymptotic variance = 2 * pi * f_hat (1 x 1)
S1 = d_bar / sqrt(asyvar/T);   % S1 test statistic (1 x 1)

% S2a test: sign test
S2 = sum(loss_diff > 0);   % 1 x 1
S2a = (S2-0.5*T)/sqrt(0.25*T);    % S2a test statistic (1 x 1)

% S3a test: Wilcoxon's signed-rank test
[~, r] = sort(abs(loss_diff));    % rank abs(loss_diff) in ascending order (T x 1)
S3 = sum((loss_diff > 0) .* r);   % 1 x 1
S3a_num = S3 - T*(T+1)/4;   % numerator of test statistic (1 x 1)
S3a_den = sqrt(T*(T+1)*(2*T+1)/24);    % denominator of test statistic (1 x 1)
S3a = S3a_num / S3a_den;    % S3a test statistic (1 x 1)
test_stats = [S1; S2a; S3a];    % collect three test statistics (3 x 1)

% compute asymptotic p-values
if H1_type == 1       % H1: loss1 ~= loss2 (the accuracy of two forecasts is different from each other) 
    pvalues = 2*(1 - normcdf(abs(test_stats)));   % 3 x 1
elseif H1_type == 2   % H1: loss1 < loss2 (first forecast is more accurate than the second)
    pvalues = normcdf(test_stats);    % 3 x 1
elseif H1_type == 3   % H1: loss1 > loss2 (second forecast is more accurate than the first)
    pvalues = 1 - normcdf(test_stats);    % 3 x 1
end     

end
