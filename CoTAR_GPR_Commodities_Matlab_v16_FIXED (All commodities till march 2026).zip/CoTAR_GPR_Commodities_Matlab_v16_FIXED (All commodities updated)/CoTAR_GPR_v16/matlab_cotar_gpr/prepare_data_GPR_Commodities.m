%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% prepare_data_GPR_Commodities.m  (v16 — final)
%
% PURPOSE: Convert raw input xlsx files into Matlab-readable .txt data files
%    required by MASTER_CoTAR_GPR_Commodities.m
%
% INPUT FILES (all xlsx — place in same folder before running):
%
%   data_gpr_export.xlsx
%       Sheet: Sheet1 (or first sheet)
%       Columns: Date | GPR | GPRTHREAT | GPRACT
%       Date format: datetime (monthly, end-of-month)
%
%   PRECIOUS METALS_monthly data.xlsx
%       Sheet: LAST
%       Columns: Date | GC1(Gold) | SI1(Silver) | PL1(Platinum)
%
%   METALS_monthly data.xlsx
%       Sheet: LAST
%       Columns: Date | HG1(Copper) | LX1(Zinc) | LN1(Nickel) | LL1(Lead)
%
%   AGRICULTURE_monthly data.xlsx
%       Sheet: LAST
%       Columns: Date | W1(Wheat) | C1(Sweetcorn) | S1(Soybean) |
%                CT1(Cotton) | CC1(Cocoa) | KC1(Coffee)
%
%   ENERGY_monthly data.xlsx
%       Sheet: Sheet1
%       Columns: Date | CL1(WTI Crude Oil) | CO1(Brent Crude) |
%                NG1(Natural Gas) | XB1(RBOB Gasoline) | HO1(Heating Oil)
%
% OUTPUT FILES (written to same folder):
%   data_GPR_monthly.txt
%       Tab-delimited, no header
%       Cols: Excel_serial | GPR | GPRTHREAT | GPRACT
%
%   data_commodity_logRV.txt
%       Tab-delimited, no header
%       Cols: Excel_serial | logRV_1 ... logRV_18
%       Column order (18 commodities):
%         1:Gold  2:Silver  3:Platinum
%         4:Wheat  5:Sweetcorn  6:Soybean  7:Cotton  8:Cocoa  9:Coffee
%         10:Copper  11:Zinc  12:Nickel  13:Lead
%         14:WTI Crude Oil  15:Brent Crude  16:Natural Gas
%         17:RBOB Gasoline  18:Heating Oil
%
% NOTE: log-RV = log(r_t^2), where r_t = log(P_t / P_{t-1})
%       Study window: 2000-01 to 2026-03  (315 monthly obs)
%
% Written for: Ozdemir et al. (2025) + CoTAR extension (GPR threshold)
% v16: All xlsx inputs, 18 commodities, sample through 2026-03
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all; clc;

date_start = datetime(2000, 1, 1);
date_end   = datetime(2026, 3, 31);

%% =========================================================================
%  PART 1: GPR DATA
%  =========================================================================
fprintf('Preparing GPR data...\n');

gpr_tbl = readtable('data_gpr_export.xlsx', 'VariableNamingRule', 'preserve');

% Identify date column (col 1) and GPR columns
gpr_dates_raw  = gpr_tbl{:, 1};
GPR_raw        = double(gpr_tbl{:, 2});   % GPR
GPRTHREAT_raw  = double(gpr_tbl{:, 3});   % GPRTHREAT
GPRACT_raw     = double(gpr_tbl{:, 4});   % GPRACT

% Parse dates robustly
if isdatetime(gpr_dates_raw)
    gpr_dates = gpr_dates_raw;
elseif isnumeric(gpr_dates_raw)
    gpr_dates = datetime(gpr_dates_raw, 'ConvertFrom', 'excel');
else
    gpr_dates = datetime(string(gpr_dates_raw));
end

% Remove NaN rows
valid_gpr = ~isnan(GPR_raw) & ~isnan(GPRTHREAT_raw) & ~isnan(GPRACT_raw);
gpr_dates     = gpr_dates(valid_gpr);
GPR_raw       = GPR_raw(valid_gpr);
GPRTHREAT_raw = GPRTHREAT_raw(valid_gpr);
GPRACT_raw    = GPRACT_raw(valid_gpr);

% Sort ascending
[gpr_dates, idx] = sort(gpr_dates);
GPR_raw       = GPR_raw(idx);
GPRTHREAT_raw = GPRTHREAT_raw(idx);
GPRACT_raw    = GPRACT_raw(idx);

% Filter to study window
mask_gpr = (gpr_dates >= date_start) & (gpr_dates <= date_end);
gpr_dates_f   = gpr_dates(mask_gpr);
GPR_f         = GPR_raw(mask_gpr);
GPRTHREAT_f   = GPRTHREAT_raw(mask_gpr);
GPRACT_f      = GPRACT_raw(mask_gpr);

% Excel serial for Matlab load compatibility
gpr_serial_f = datenum(gpr_dates_f) - datenum(datetime(1899, 12, 30));

dlmwrite('data_GPR_monthly.txt', ...
    [gpr_serial_f, GPR_f, GPRTHREAT_f, GPRACT_f], ...
    'delimiter', '\t', 'precision', '%.6f');
fprintf('  -> data_GPR_monthly.txt: %d rows\n', sum(mask_gpr));

%% =========================================================================
%  PART 2: COMMODITY PRICE DATA
%  =========================================================================
fprintf('Preparing commodity price data...\n');

%% ── Precious Metals (Sheet: LAST, cols: Date | Gold | Silver | Platinum) ─
pm_tbl = readtable('PRECIOUS METALS_monthly data.xlsx', ...
                   'Sheet', 'LAST', 'VariableNamingRule', 'preserve');
pm_dates  = parse_dates(pm_tbl{:,1});
Gold      = double(pm_tbl{:,2});
Silver    = double(pm_tbl{:,3});
Platinum  = double(pm_tbl{:,4});
[pm_dates, idx] = sort(pm_dates);
Gold=Gold(idx); Silver=Silver(idx); Platinum=Platinum(idx);

%% ── Industrial Metals (Sheet: LAST, cols: Date | Copper | Zinc | Nickel | Lead) ─
me_tbl = readtable('METALS_monthly data.xlsx', ...
                   'Sheet', 'LAST', 'VariableNamingRule', 'preserve');
me_dates = parse_dates(me_tbl{:,1});
Copper = double(me_tbl{:,2});
Zinc   = double(me_tbl{:,3});
Nickel = double(me_tbl{:,4});
Lead   = double(me_tbl{:,5});
[me_dates, idx] = sort(me_dates);
Copper=Copper(idx); Zinc=Zinc(idx); Nickel=Nickel(idx); Lead=Lead(idx);

%% ── Agriculture (Sheet: LAST, cols: Date | Wheat | Corn | Soy | Cotton | Cocoa | Coffee) ─
ag_tbl = readtable('AGRICULTURE_monthly data.xlsx', ...
                   'Sheet', 'LAST', 'VariableNamingRule', 'preserve');
ag_dates  = parse_dates(ag_tbl{:,1});
Wheat     = double(ag_tbl{:,2});
Sweetcorn = double(ag_tbl{:,3});
Soybean   = double(ag_tbl{:,4});
Cotton    = double(ag_tbl{:,5});
Cocoa     = double(ag_tbl{:,6});
Coffee    = double(ag_tbl{:,7});
[ag_dates, idx] = sort(ag_dates);
Wheat=Wheat(idx); Sweetcorn=Sweetcorn(idx); Soybean=Soybean(idx);
Cotton=Cotton(idx); Cocoa=Cocoa(idx); Coffee=Coffee(idx);

%% ── Energy (CSV CLEAN FILES — FIXED) ─────────────────────────────

brent = readtable('Brent_Crude_clean.csv');
wti   = readtable('WTI_Crude_Oil_clean.csv');
ng    = readtable('Natural_Gas_clean.csv');
rbob  = readtable('RBOB_Gasoline_clean.csv');
ho    = readtable('Heating_Oil_clean.csv');

% Convert dates
brent.Date = datetime(brent.Date);
wti.Date   = datetime(wti.Date);
ng.Date    = datetime(ng.Date);
rbob.Date  = datetime(rbob.Date);
ho.Date    = datetime(ho.Date);

% Convert to timetable
brent = table2timetable(brent);
wti   = table2timetable(wti);
ng    = table2timetable(ng);
rbob  = table2timetable(rbob);
ho    = table2timetable(ho);

% Convert daily → monthly
brent = retime(brent,'monthly','lastvalue');
wti   = retime(wti,'monthly','lastvalue');
ng    = retime(ng,'monthly','lastvalue');
rbob  = retime(rbob,'monthly','lastvalue');
ho    = retime(ho,'monthly','lastvalue');

% Merge all energy series
en_tt = synchronize(brent, wti, ng, rbob, ho);

% Convert back to table
en_tbl = timetable2table(en_tt);

% Rename columns properly
en_tbl.Properties.VariableNames = {'Date','Brent_Crude','WTI_Crude_Oil','Natural_Gas','RBOB_Gasoline','Heating_Oil'};

% Extract variables (IMPORTANT ORDER)
en_dates      = en_tbl.Date;
WTI_Crude_Oil = en_tbl.WTI_Crude_Oil;
Brent_Crude   = en_tbl.Brent_Crude;
Natural_Gas   = en_tbl.Natural_Gas;
RBOB_Gasoline = en_tbl.RBOB_Gasoline;
Heating_Oil   = en_tbl.Heating_Oil;
%% ── Use Precious Metals dates as master (spans full period) ──────────────
master_dates = pm_dates;

% Align all series to master dates using month-matching
[Gold_a,         ~] = align_series(pm_dates, Gold,         master_dates);
[Silver_a,       ~] = align_series(pm_dates, Silver,       master_dates);
[Platinum_a,     ~] = align_series(pm_dates, Platinum,     master_dates);
[Wheat_a,        ~] = align_series(ag_dates, Wheat,        master_dates);
[Sweetcorn_a,    ~] = align_series(ag_dates, Sweetcorn,    master_dates);
[Soybean_a,      ~] = align_series(ag_dates, Soybean,      master_dates);
[Cotton_a,       ~] = align_series(ag_dates, Cotton,       master_dates);
[Cocoa_a,        ~] = align_series(ag_dates, Cocoa,        master_dates);
[Coffee_a,       ~] = align_series(ag_dates, Coffee,       master_dates);
[Copper_a,       ~] = align_series(me_dates, Copper,       master_dates);
[Zinc_a,         ~] = align_series(me_dates, Zinc,         master_dates);
[Nickel_a,       ~] = align_series(me_dates, Nickel,       master_dates);
[Lead_a,         ~] = align_series(me_dates, Lead,         master_dates);
[WTI_a,          ~] = align_series(en_dates, WTI_Crude_Oil, master_dates);
[Brent_a,        ~] = align_series(en_dates, Brent_Crude,   master_dates);
[NatGas_a,       ~] = align_series(en_dates, Natural_Gas,   master_dates);
[RBOBGas_a,      ~] = align_series(en_dates, RBOB_Gasoline, master_dates);
[HeatingOil_a,   ~] = align_series(en_dates, Heating_Oil,   master_dates);

%% ── Compute log-RV = log(r_t^2) for each commodity ─────────────────────
all_prices = [Gold_a, Silver_a, Platinum_a, ...
              Wheat_a, Sweetcorn_a, Soybean_a, Cotton_a, Cocoa_a, Coffee_a, ...
              Copper_a, Zinc_a, Nickel_a, Lead_a, ...
              WTI_a, Brent_a, NatGas_a, RBOBGas_a, HeatingOil_a];

n_total  = size(all_prices, 1);
n_assets = size(all_prices, 2);   % 18
logRV    = NaN(n_total, n_assets);

for k = 1:n_assets
    p_vec = all_prices(:, k);
    p_vec(p_vec <= 0) = NaN;
    r     = log(p_vec(2:end) ./ p_vec(1:end-1));
    r2    = r .^ 2;
    r2(r2 == 0) = NaN;
    logRV(2:end, k) = log(r2);
end

% log-RV dates (one row fewer than prices due to differencing)
logRV_dates  = master_dates(2:end);
logRV_serial = datenum(logRV_dates) - datenum(datetime(1899, 12, 30));
logRV_out    = logRV(2:end, :);

% Filter to study window
mask_comm = (logRV_dates >= date_start) & (logRV_dates <= date_end);
logRV_serial_f = logRV_serial(mask_comm);
logRV_out_f    = logRV_out(mask_comm, :);

dlmwrite('data_commodity_logRV.txt', ...
    [logRV_serial_f, logRV_out_f], ...
    'delimiter', '\t', 'precision', '%.6f');
fprintf('  -> data_commodity_logRV.txt: %d rows x %d commodities\n', ...
        sum(mask_comm), n_assets);

fprintf('\nData preparation complete.\n');
fprintf('Now run:  MASTER_CoTAR_GPR_Commodities\n');

%% =========================================================================
%  LOCAL HELPER FUNCTIONS
%  =========================================================================

function d = parse_dates(raw)
% Parse a column of dates (datetime, numeric serial, char, or string).
    if isdatetime(raw)
        d = raw;
    elseif isnumeric(raw)
        d = datetime(raw, 'ConvertFrom', 'excel');
    else
        d = datetime(string(raw));
    end
end

function [vals_aligned, dates_out] = align_series(dates_src, vals_src, dates_target)
% Align vals_src to dates_target by matching year-month.
    n_target    = length(dates_target);
    vals_aligned = NaN(n_target, 1);
    src_ym = year(dates_src)  * 100 + month(dates_src);
    tgt_ym = year(dates_target) * 100 + month(dates_target);
    for t = 1:n_target
        idx = find(src_ym == tgt_ym(t), 1);
        if ~isempty(idx)
            vals_aligned(t) = vals_src(idx);
        end
    end
    dates_out = dates_target;
end
