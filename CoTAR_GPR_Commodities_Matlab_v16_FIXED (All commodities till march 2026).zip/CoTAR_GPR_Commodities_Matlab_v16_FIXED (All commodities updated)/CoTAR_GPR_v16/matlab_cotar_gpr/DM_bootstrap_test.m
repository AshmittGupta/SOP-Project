function pval = DM_bootstrap_test(loss1, loss2)

% Wild bootstrap DM test matching empirics_outsample_DMtest_v7.m

rng(0,'twister');

d = loss1 - loss2;
T = length(d);

d_bar = mean(d);

B = 5000;
boot_stats = zeros(B,1);

for b = 1:B
    
    v = randn(T,1);
    d_star = d .* v;
    
    boot_stats(b) = sqrt(T) * mean(d_star);
    
end

actual_stat = sqrt(T) * d_bar;

pval = mean(abs(boot_stats) >= abs(actual_stat));

end