function results = est_CoTAR_v3(y, x, p, ds, ms, cutoff)
% PURPOSE: Compute the profiling estimator of the Conditional 
%    Threshold Autoregressive (CoTAR) model and perform 1-step-ahead 
%    out-of-sample prediction for y(n+1).
%--------------------------------------------------------------------------
% USAGE: results = est_CoTAR_v3(y, x, p, ds, ms, cutoff)
% where: y = target variable (n x 1)
%               n = sample size
%        x = threshold variable (n x 1)
%        p = AR lag length (1 x 1) 
%        ds = candidate values of delay parameter (num_d x 1)
%            num_d = # of candidate values of delay parameter 
%        ms = candidate values of memory size (num_m x 1)
%            num_m = # of candidate values of memory size 
%        cutoff = cut-off value of the share of each regime (1 x 1)
%               If the shares of both regimes are above cutoff (say 0.15),
%                   then implement LS. Otherwise, assign SSR = inf.
%--------------------------------------------------------------------------
% RETURNS: results = structure
%    results.beta_hat = [beta1_hat; beta2_hat] (K x 1)
%               where betar_hat = estimated AR parameters in regime r
%                     K = 2*(p+1)
%    results.gamma_hat = [d_hat; m_hat; c_hat] (3 x 1)
%    results.theta_hat = [beta_hat; gamma_hat] ((K+3) x 1)
%    results.y_hat_outsample = 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)
%--------------------------------------------------------------------------
% Conditional Threshold Autoregressive (CoTAR) model: 
%     y(t) = alpha1 + SUM(phi1(k)*y(t-k)) + u(t)
%                if x(t-d) < mu(t-d-1; m, c)
%          = alpha2 + SUM(phi2(k)*y(t-k)) + u(t)
%                if x(t-d) >= mu(t-d-1; m, c)
%     mu(t; m, c) = (m*c)-th smallest value of {x(t), x(t-1), ..., x(t-m+1)}
%     beta1 = [alpha1, phi1(1), ..., phi1(p)]' 
%     beta2 = [alpha2, phi2(1), ..., phi2(p)]' 
%     beta = [beta1', beta2']' 
%     gamma = [d, m, c]'
%     When y = x, we have the self-exciting CoTAR (SE-CoTAR) model.
% -------------------------------------------------------------------------
% See also: est_CoTAR_gamma_v2.m
% -------------------------------------------------------------------------
% References: 
%     K. Motegi, J. W. Dennis, and S. Hamori (2024). Conditional Threshold 
%        Autoregression (CoTAR). SSRN Working Paper #3960058.
%     B. E. Hansen (1996). Inference When a Nuisance Parameter Is Not 
%        Identified Under the Null Hypothesis. Econometrica, vol. 64, 
%        pp. 413-430.
%--------------------------------------------------------------------------
% Written by:
%     Kaiji Motegi, Ph.D.
%     Associate Professor
%     Graduate School of Economics, Kobe University.
% -------------------------------------------------------------------------
% Last updated: August 27, 2024.
% -------------------------------------------------------------------------

% construct a matrix which aligns all possible pairs of (m,c)
% If ms = [1, 2, 3], then mcs is constucted as follows.
% mcs = [1, 1/1;
%        2, 1/2;
%        2, 2/2;
%        3, 1/3;
%        3, 2/3;
%        3, 3/3]
num_m = length(ms);   % # of candidate values of m
mcs = [];
for i = 1:num_m
     m = ms(i);   % 1 x 1
     cs = (1/m)*(1:m)';   % m x 1
     mcs = [mcs; m*ones(m,1), cs];
end    
num_mcs = size(mcs,1);    % # of all possible pairs of (m,c) (1 x 1)

% construct a matrix which aligns all possible combinations of gamma = (d,m,c)'
% If ds = [1, 2] and ms = [1, 2, 3], then gammas is constructed as follows.
% gammas = [1, 1, 1/1;
%           1, 2, 1/2;
%           1, 2, 2/2;
%           1, 3, 1/3;
%           1, 3, 2/3;
%           1, 3, 3/3;
%           2, 1, 1/1;
%           2, 2, 1/2;
%           2, 2, 2/2;
%           2, 3, 1/3;
%           2, 3, 2/3;
%           2, 3, 3/3]
num_d = length(ds);   % # of candidate values of d
gammas = [];
for i = 1:num_d
     d = ds(i);   % 1 x 1
     gammas = [gammas; d*ones(num_mcs,1), mcs];
end    
num_gamma = size(gammas,1);   % # of all possible combinations of gamma (1 x 1)

% exhaust all possible values of gamma
SSR = inf;
for g = 1:num_gamma
     gamma_temp = gammas(g,:)';   % fix gamma (3 x 1)
     
     % implement conditional least squares given gamma
     [~, SSR_temp] = est_CoTAR_gamma_v2(y, x, p, gamma_temp, cutoff);
         
     % If SSR is the smaller than before, update the estimates and SSR
     if SSR_temp < SSR
         gamma_hat = gamma_temp;   % 3 x 1
         SSR = SSR_temp;   % 1 x 1
     end    
end

% use the optimal gamma
[beta_hat, ~, y_hat_outsample] = est_CoTAR_gamma_v2(y, x, p, gamma_hat, cutoff);

% save results
results.beta_hat = beta_hat;     % K x 1
results.gamma_hat = gamma_hat;   % 3 x 1
results.theta_hat = [beta_hat; gamma_hat];   % (K+3) x 1
results.y_hat_outsample = y_hat_outsample;   % 1-step-ahead out-of-sample prediction for y(n+1) (1 x 1)
    
end
